#ifndef __WEATHER_CURVE_H
#define __WEATHER_CURVE_H

/* C++ detection */
#ifdef __cplusplus
extern "C" {
#endif


float Weather_curve (float, float, float, float, char);



#endif
