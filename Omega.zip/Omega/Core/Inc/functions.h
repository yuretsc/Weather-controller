/*
 * Functions.h
 *
 *  Created on: Apr 8, 2020
 *      Author: Admin
 */

#ifndef INC_FUNCTIONS_H_
#define INC_FUNCTIONS_H_

//#define ClearBit(A,k)   (A &= ~(1UL << k))
//#define SetBit(A,k)    (A |= 1UL << k)
//#define TestBit(A,k) ((A >> k) & 1UL)
//#define ToggleBit(A,k)  ( A ^= 1UL << k)

#include "stm32f1xx_hal.h"

// обработка кнопок
typedef struct
{
	uint32_t key_up; /* разрешение */
	uint32_t key_down; /* разрешение */
	uint32_t key_left; /*входная величина*/
	uint32_t key_right; /*задание*/
	uint32_t time_privat[8]; /*время нажатия мс*/
	uint32_t R_trig_privat;
	uint8_t key_up_fall; /* отпускание кнопки */
	uint8_t key_down_fall; /* отпускание кнопки */
	uint8_t key_left_fall; /* отпускание кнопки */
	uint8_t key_right_fall; /*отпускание кнопки*/
	uint8_t key_up_rise; /* отпускание кнопки */
	uint8_t key_down_rise; /* отпускание кнопки */
	uint8_t key_left_rise; /* отпускание кнопки */
	uint8_t key_right_rise; /*отпускание кнопки*/
} key_DataType;

// регулятор дискретный
typedef struct
{
	uint8_t out; /* разрешение */
	uint8_t en; /* разрешение */
	uint16_t in; /*входная величина*/
	uint16_t set; /*задание*/
	uint16_t hyst; /*гистерезис*/
	uint32_t min_time; /*минимальный сигнал в mс*/
	uint32_t time_privat; /*время вызова мс*/
} discr_reg_DataType;

typedef struct
{
	uint8_t en; // разрешение
	int16_t period; /*!< период вызова регулятора, с*/
	int16_t K; /*!< коэффициент усиления регулятора*/
	int16_t valve_time; /*!< время полного открытия клапана в с*/
	int16_t min_valve_time; /*!< минимальная длинна импульса в мс*/
	int16_t lag_valve_time; /*!< люфт клапана в мс*/
	int16_t valve_time_pause; /*!< минимальная пауза в мс*/
	int16_t Model_pos;/*!<положение клапана вычисленное*/
	int16_t Ti;
	int16_t Td;
	float imp_time;
	int16_t out; /*!< выходной сигнал регулятора*/
	int16_t input; /*!< вход регулятора*/
	int16_t set; /*!< уставка регулятора*/
	int16_t up;/*!< регулятор больше*/
	int16_t down;/*!<регулятор меньше*/
	int32_t lastInput;
	int32_t lastlastInput;
}
P_reg_DataType;
// ошибки
typedef struct
{
	uint8_t code; // код ошибки
	int16_t T1_H; /* перегрев Т1 */
	int16_t T2_H; /* перегрев Т2 */
	int16_t T3_H; /* перегрев Т3 */
	int16_t T4_H; /* перегрев Т4 */
	int16_t T1_memory_privat; /*сохраненное значение Т1*/
	int16_t T2_memory_privat; /*сохраненное значение Т2*/
	int16_t T3_memory_privat; /*сохраненное значение Т3*/
	int16_t T4_memory_privat; /*сохраненное значение Т4*/
	int16_t R_trig_privat; /*триггер*/
	uint32_t dtime_privat; /*время сравнение прироста температуры мс*/
	uint32_t etime_privat; /*время длительности ошибки мс*/
	uint32_t time_privat[16];//*время для сохранения ошибки мс*/
} error_DataType;

typedef struct
{
	uint8_t Night_shift_time_flash[7][6];
	int16_t Boiler_set; //???
	int16_t Boiler_hyst;//???
	int16_t Set_temp_WWS;
	int16_t Set_hyst_WWS;
	int16_t P_regDataFlow_Flow_period;
	int16_t P_regDataFlow_K;
	int16_t P_regDataFlow_valve_time;
	int16_t P_regDataFlow_min_valve_time;
	int16_t P_regDataFlow_lag_valve_time;
	int16_t P_regDataFlow_valve_time_pause;
	int16_t P_regDataFlow_Ti;
	int16_t P_regDataFlow_Td;
	int16_t Weather_curve_Set_T_room;
	int16_t Weather_curve_Set_N_graph_shift;
	int16_t Weather_curve_S_graph_slope;
	int16_t Weather_curve_Set_T_max;
	int16_t Weather_curve_Set_Night_shift;
	int16_t lang_flash;
	int16_t Summ_Temp[4];
	int16_t Mul_Temp[4];
	int16_t Contrast;
	uint16_t Setpoint;
	uint16_t Boiler_WWS;
	uint8_t Power;
	uint8_t Weather_curve_en;
	uint8_t Priority_WWS;
	uint8_t Antifrost;
	uint8_t WWS_en;
	uint8_t Boiler_en;
	uint8_t Temperature_visu[4];
} Flash_DataType;

void discr_reg (discr_reg_DataType*);
uint8_t func_error (error_DataType* code_error);
void func_key (key_DataType*);
void PDD_PWM (P_reg_DataType*);
void FLASH_Write (uint32_t *data, uint32_t adres, uint16_t length);
int16_t limit (int16_t data, int16_t min, int16_t max);
uint32_t RTC_GetRTC_Counter(RTC_DateTypeDef* RTC_DateStruct, RTC_TimeTypeDef* RTC_TimeStruct);
void RTC_GetDateTime(uint32_t RTC_Counter, RTC_DateTypeDef* RTC_DateStruct/*, RTC_TimeTypeDef* RTC_TimeStruct*/);
void Flash_memory_write (void);

#endif /* INC_FUNCTIONS_H_ */
