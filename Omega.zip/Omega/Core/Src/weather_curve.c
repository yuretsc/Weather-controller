#include "weather_curve.h"



float Weather_curve (float T_outdoor, float T_room, float N_graph_shift,float S_graph_slope, char T_max )
{

	float dT = T_outdoor - T_room;
	float A = 1.149+0.021*dT+0.00015*dT*dT;
	float Tout = (T_room + N_graph_shift - S_graph_slope*dT*A);
	if (Tout > ((float)T_max)) return ((float)T_max);
	if (Tout < T_room) return T_room;
	return (T_room + N_graph_shift - S_graph_slope*dT*A);

}
