/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "ssd1306.h"
#include "onewire.h"
#include "ds18b20.h"
#include "image.h"
#include "weather_curve.h"
#include "stm32f1xx_hal_rtc.h"
#include "functions.h"
#include "stm32f1xx_hal_rtc_ex.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
#define ClearBit(A,k)   (A &= ~(1UL << k))
#define SetBit(A,k)    (A |= 1UL << k)
#define TestBit(A,k) ((A >> k) & 1UL)
#define ToggleBit(A,k)  ( A ^= 1UL << k)
#define Num_DS18B20 4
#define Temperature_outdoor Temperature[0]



/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c2;
DMA_HandleTypeDef hdma_i2c2_tx;

RTC_HandleTypeDef hrtc;

TIM_HandleTypeDef htim3;

/* USER CODE BEGIN PV */
uint16_t Set_temp_WWS;// задание температуры ГВС
uint16_t Set_hyst_WWS;// задание гистерезиса ГВС
const char celsium []= {191,'C'};
int16_t Temperature[4] ={-1250,-1250,-1250,-1250}; // измеренные температуры
uint8_t Temperature_error[4]; // счетчик ошибок измерения температуры
uint8_t Temperature_visu[4]; // счетчик ошибок измерения температуры
//Temperature_outdoor - температура на улице
//Temperature[1] - температура в контуре отопления
//Temperature[2] - температура ГВС
//Temperature[3] - температура источника тепла
int16_t Summ_Temp[4] ={-10,-5,-5,-5}; // измеренные температуры
int16_t Mul_Temp[4] ={1000,1000,1000,1000}; // измеренные температуры
int Blink=0;

int16_t Contrast = 5;//контрастность дисплея
uint8_t Night_shift;
uint8_t error;
uint8_t edit = 0;
uint8_t last_edit = 0;
uint8_t edit_string =0;
uint8_t Set_Weekday = 3;
uint8_t Night_shift_time[7][6] = {{0x00, 0x00, 0x00, 0x00, 0x00, 0x00}, {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}, {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}, {0xAA, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}, {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}, {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}, {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}}; //ночное время, 7 дней недели, 24 часа по 30 минут = 48 бит на день(6байт)
// hour*2+min/30
/* Onewire structure */
OneWire_t OW[Num_DS18B20];
/* Array for DS18B20 ROM number */
uint8_t DS_ROM[Num_DS18B20][8];
//DS18B20_Resolution_t Resolution;

discr_reg_DataType Boiler = {0,1,0,80,5,30000};
discr_reg_DataType WWS_pump = {0,1,0,55,5,30000};
key_DataType key;
error_DataType code_error;
uint8_t Weather_curve_en = 0;
uint16_t Setpoint = 40;
uint8_t Priority_WWS=0;
uint8_t Antifrost=1;
uint8_t WWS_en=1;
uint16_t Boiler_WWS = 70;
//uint16_t Boiler_hyst = 70;

P_reg_DataType P_regDataFlow = {1,10 ,20 ,120 ,500 ,100, 1000, 0, 10};
RTC_TimeTypeDef gTime = {0};
RTC_DateTypeDef gDate = {0};
RTC_TimeTypeDef Set_gTime = {0};
RTC_DateTypeDef Set_gDate = {0};

float Weather_curve_value;
uint8_t page = 0;
int16_t lang = 0;
uint8_t Power;
int16_t Set_T_room = 20;
int16_t Set_N_graph_shift = 0;
int16_t S_graph_slope = 10;
int16_t Set_T_max = 90;
int16_t Set_Night_shift = -10;
uint32_t BKUPTimeSave;
uint32_t BKUPData;

Flash_DataType Flash_memory;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_I2C2_Init(void);
static void MX_RTC_Init(void);
static void MX_TIM3_Init(void);
/* USER CODE BEGIN PFP */
void LCD_func (uint16_t);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_I2C2_Init();
  MX_RTC_Init();
	// Включить тактирование модулей управления питанием и управлением резервной областью
  __HAL_RCC_BKP_CLK_ENABLE();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */
#ifdef NDEBUG
    if (FLASH_GetReadOutProtectionStatus() == RESET)
    {
        FLASH_Unlock();
        FLASH_ReadOutProtection(ENABLE);
        FLASH_Lock();
    }
#endif
  ssd1306_Init(hi2c2,0x78);
	/* Init ONEWIRE port on PA3 pin */

	 Ds18b20_Init(&OW[0], DS_ROM[0], Temp_1_GPIO_Port, Temp_1_Pin);
	 Ds18b20_Init(&OW[1], DS_ROM[1], Temp_2_GPIO_Port, Temp_2_Pin);
	 Ds18b20_Init(&OW[2], DS_ROM[2], Temp_3_GPIO_Port, Temp_3_Pin);
	 Ds18b20_Init(&OW[3], DS_ROM[3], Temp_4_GPIO_Port, Temp_4_Pin);

for (uint8_t t=0; t<Num_DS18B20; t++)
	{
	  if (DS18B20_Is(DS_ROM[t]))
	  {
			// Set resolution
			DS18B20_SetResolution(&OW[t], DS_ROM[t], DS18B20_Resolution_12bits);

			// Start conversion on all sensors
			DS18B20_StartAll(&OW[t]);
		}
	}

	ssd1306_Fill(Black);
	SSD1306_DrawLine (0,27,128,27, White);
	SSD1306_DrawLine (0,37,128,37, White);
	SSD1306_DrawLine (0,27,0,37, White);
	SSD1306_DrawLine (128,27,128,37, White);
	for (uint8_t i=1; i<128; i++)
	{
	  SSD1306_DrawLine (i,27,i,37, White);
	  ssd1306_UpdateScreen();
	  HAL_Delay(17);
	}


	//-------------------------------чтение из FLASH---------------------------------------------
	  key.key_up=(uint32_t)!HAL_GPIO_ReadPin(Key_UP_GPIO_Port, Key_UP_Pin);
	  if (key.key_up == 0)
	  {
		Flash_DataType *Flashcopy = ( Flash_DataType *)0x0801FC00;
		P_regDataFlow.K = Flashcopy->P_regDataFlow_K;
		P_regDataFlow.Ti = Flashcopy->P_regDataFlow_Ti;
		P_regDataFlow.Td = Flashcopy->P_regDataFlow_Td;
		P_regDataFlow.valve_time = Flashcopy->P_regDataFlow_valve_time;
		P_regDataFlow.min_valve_time = Flashcopy->P_regDataFlow_min_valve_time;
		P_regDataFlow.lag_valve_time = Flashcopy->P_regDataFlow_lag_valve_time;
		P_regDataFlow.valve_time_pause = Flashcopy->P_regDataFlow_valve_time_pause;
		P_regDataFlow.period = Flashcopy->P_regDataFlow_Flow_period;
		Set_T_room = Flashcopy->Weather_curve_Set_T_room;
		Set_N_graph_shift = Flashcopy->Weather_curve_Set_N_graph_shift;
		S_graph_slope = Flashcopy->Weather_curve_S_graph_slope;
		Set_T_max = Flashcopy->Weather_curve_Set_T_max;
		Set_Night_shift = Flashcopy->Weather_curve_Set_Night_shift;
		lang = Flashcopy->lang_flash;
		Set_temp_WWS = Flashcopy->Set_temp_WWS;
		Set_hyst_WWS = Flashcopy->Set_hyst_WWS;
		Summ_Temp[0] = Flashcopy->Summ_Temp[0];
		Summ_Temp[1] = Flashcopy->Summ_Temp[1];
		Summ_Temp[2] = Flashcopy->Summ_Temp[2];
		Summ_Temp[3] = Flashcopy->Summ_Temp[3];
		Mul_Temp[0] = Flashcopy->Mul_Temp[0];
		Mul_Temp[1] = Flashcopy->Mul_Temp[1];
		Mul_Temp[2] = Flashcopy->Mul_Temp[2];
		Mul_Temp[3] = Flashcopy->Mul_Temp[3];
		Contrast = Flashcopy->Contrast;
		Power = Flashcopy->Power;
		Weather_curve_en = Flashcopy->Weather_curve_en;
		Setpoint = Flashcopy->Setpoint;
		Priority_WWS = Flashcopy->Priority_WWS;
		Antifrost = Flashcopy->Antifrost;
		WWS_en = Flashcopy->WWS_en;
		Boiler.hyst = Flashcopy->Boiler_hyst;
		Boiler_WWS = Flashcopy->Boiler_WWS;
    	Temperature_visu[0]=Flashcopy->Temperature_visu[0];
    	Temperature_visu[1]=Flashcopy->Temperature_visu[1];
    	Temperature_visu[2]=Flashcopy->Temperature_visu[2];
    	Temperature_visu[3]=Flashcopy->Temperature_visu[3];

		for (int i = 0; i < 7; ++i)
		{
		  for (int j = 0; j < 6; ++j)
			  Night_shift_time[i][j] = Flashcopy->Night_shift_time_flash[i][j];
		}
	  }
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
//----------восстанавливаем последнее сохраненное время---------
	  BKUPTimeSave = (HAL_RTCEx_BKUPRead(&hrtc, RTC_BKP_DR7)<<16) + HAL_RTCEx_BKUPRead(&hrtc, RTC_BKP_DR8);
// добавляем к глобальному счетчику значение текущего времени и вычитаем время последнего сохранения
	  BKUPData = ((HAL_RTCEx_BKUPRead(&hrtc, RTC_BKP_DR9)<<16) + HAL_RTCEx_BKUPRead(&hrtc, RTC_BKP_DR10)) + ((hrtc.Instance->CNTH << 16) + hrtc.Instance->CNTL) - BKUPTimeSave;
// расчет даты из памяти и запись
	  RTC_GetDateTime(BKUPData, &Set_gDate);
	  if (HAL_RTC_SetDate(&hrtc, &Set_gDate, RTC_FORMAT_BIN) != HAL_OK)
	  {
	    Error_Handler();
	  }

	  while (1)
  {

	  //----------------------запись в BKP registers--------------
	  uint32_t BKUPTime = BKUPData - BKUPTimeSave + ((hrtc.Instance->CNTH << 16) + hrtc.Instance->CNTL);
	  //----------------сохраняем текущее время-------------------
	  HAL_RTCEx_BKUPWrite(&hrtc, RTC_BKP_DR7, hrtc.Instance->CNTH);
	  HAL_RTCEx_BKUPWrite(&hrtc, RTC_BKP_DR8, hrtc.Instance->CNTL);
	  //----------------сохраняем глобальное время-------------------
	  HAL_RTCEx_BKUPWrite(&hrtc, RTC_BKP_DR9, BKUPTime >> 16);
	  HAL_RTCEx_BKUPWrite(&hrtc, RTC_BKP_DR10, BKUPTime & 0x0000FFFF);

//---------------------------limit variables-----------------------
		P_regDataFlow.K = limit (P_regDataFlow.K, 0, 1000);
		P_regDataFlow.Ti = limit (P_regDataFlow.Ti, 0, 10000);
		P_regDataFlow.Td = limit (P_regDataFlow.Td, 0, 100);
		P_regDataFlow.valve_time = limit (P_regDataFlow.valve_time, 0, 1000);
		P_regDataFlow.min_valve_time = limit (P_regDataFlow.min_valve_time, 0, 5000);
		P_regDataFlow.lag_valve_time = limit (P_regDataFlow.lag_valve_time, 0, 1000);
		P_regDataFlow.valve_time_pause = limit (P_regDataFlow.valve_time_pause, 0, 100);
		P_regDataFlow.period = limit (P_regDataFlow.period, 0, 100);
		Set_T_room = limit (Set_T_room, 10, 40);
		Set_N_graph_shift = limit (Set_N_graph_shift, -20, 20);
		S_graph_slope = limit (S_graph_slope, 0, 60);
		Set_T_max = limit (Set_T_max, 40, 99);
		Set_Night_shift = limit (Set_Night_shift, -20, 0);
		lang = limit (lang, 0, 2);
		Set_temp_WWS = limit (Set_temp_WWS, 30, 60);
		Set_hyst_WWS = limit (Set_hyst_WWS, 0, 20);
		Set_gDate.Month = (uint8_t)limit ((int16_t)Set_gDate.Month, 0, 12);
		Set_gDate.Date = (uint8_t)limit ((int16_t)Set_gDate.Date, 0, 31);
		Set_gTime.Seconds = (uint8_t)limit ((int16_t)Set_gTime.Seconds, 0, 60);
		Set_gTime.Minutes = (uint8_t)limit ((int16_t)Set_gTime.Minutes, 0, 60);
		Set_gTime.Hours = (uint8_t)limit ((int16_t)Set_gTime.Hours, 0, 24);
		Summ_Temp[0] = limit (Summ_Temp[0], -100, 100);
		Summ_Temp[1] = limit (Summ_Temp[1], -100, 100);
		Summ_Temp[2] = limit (Summ_Temp[2], -100, 100);
		Summ_Temp[3] = limit (Summ_Temp[3], -100, 100);
		Mul_Temp[0]	= limit (Mul_Temp[0], 500, 1500);
		Mul_Temp[1]	= limit (Mul_Temp[1], 500, 1500);
		Mul_Temp[2]	= limit (Mul_Temp[2], 500, 1500);
		Mul_Temp[3]	= limit (Mul_Temp[3], 500, 1500);
		Contrast = limit (Contrast, 1, 10);
		Weather_curve_en = limit (Weather_curve_en, 0, 1);
		Setpoint = limit (Setpoint, 0, 115);
		Priority_WWS = limit (Priority_WWS, 0, 1);
		WWS_en = limit (WWS_en, 0, 1);
		Boiler_WWS = limit (Boiler_WWS, Set_temp_WWS, 99);
		Temperature_error[0] = limit (Temperature_error[0], 0, 254);
		Temperature_error[1] = limit (Temperature_error[1], 0, 254);
		Temperature_error[2] = limit (Temperature_error[2], 0, 254);
		Temperature_error[3] = limit (Temperature_error[3], 0, 254);

	  //------------------------обработка входов---------------- (цикл 30мс)
	  if ( HAL_GetTick()%1000 > 950) // запуск раз в секунду
	  {
		  for (uint8_t t=0; t<Num_DS18B20; t++)
			{
			  if (DS18B20_Is(DS_ROM[t]))
			  {
					// Everything is done
					if (DS18B20_AllDone(&OW[t])) {
						 //Read temperature from device
						float Temperature_float;
						if (DS18B20_Read(&OW[t], DS_ROM[t], &Temperature_float))
						{
							if (Temperature_error[t]>0) Temperature_error[t]--; //Temp read OK, CRC is OK
//------------------------коррекция входов-------------------------------------------------
							Temperature[t] = ((int16_t)((Temperature_float*10.0f+(float)Summ_Temp[t])/((float)Mul_Temp[t]/1000.0f)));
							// Start again on all sensors
							DS18B20_StartAll(&OW[t]);

						}
					}
				}
			  	else
				{
					if (Temperature_error[t]<255) Temperature_error[t]++;
				}
				if (Temperature_error[t]>200) Temperature[t] = -1250; // CRC failed, hardware problems on data line
			}
	  }






    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

//-------------------------------запись в FLASH---------------------------------------------

	  if (edit==0 && last_edit!=0 && page!=7)
		  {
		  Flash_memory_write();
		  }
	  last_edit=edit;

  //------------------------обработка кнопок----------------
  	  key.key_up=(uint32_t)!HAL_GPIO_ReadPin(Key_UP_GPIO_Port, Key_UP_Pin);
  	  key.key_down=(uint32_t)!HAL_GPIO_ReadPin(Key_DOWN_GPIO_Port, Key_DOWN_Pin);
  	  key.key_left=(uint32_t)!HAL_GPIO_ReadPin(Key_LEFT_GPIO_Port, Key_LEFT_Pin);
	  key.key_right=(uint32_t)!HAL_GPIO_ReadPin(Key_RIGHT_GPIO_Port, Key_RIGHT_Pin);
  	  func_key(&key);

  //------------------------дискретные регуляторы----------------
  	  //----------насос горячей воды
  	  WWS_pump.in = Temperature[2]/10;
  	  WWS_pump.set = Set_temp_WWS;
  	  WWS_pump.hyst = Set_hyst_WWS;
  	  WWS_pump.en = WWS_en & Power; // включение регулятора
  	  discr_reg(&WWS_pump);
  	  //---------управление котлом
  	  if (((uint16_t)Weather_curve_value < WWS_pump.set) && WWS_pump.out)
  	  {
  		  Boiler.set = Boiler_WWS;// поддерживаем температуру на котле для нагрева ГВС
  	  }
  	  else {
  		  Boiler.set = (uint16_t)Weather_curve_value + Boiler.hyst;// поддерживаем на Boiler.hyst больше чем требует отопление
  	  }

  	  Boiler.in = Temperature[3]/10;
  	  Boiler.en = Power; // включение регулятора
  	  discr_reg(&Boiler);


//---------------------------------погодный регулятор-------------------------------
	  Weather_curve_value = Weather_curve(((float)Temperature_outdoor)/10, (float)Set_T_room, (float)Set_N_graph_shift, ((float)S_graph_slope)/10, Set_T_max);
//---------------------------------ночное понижение---------------------------------
	  Night_shift = ( Night_shift_time[gDate.WeekDay][gTime.Hours /4] >> (gTime.Hours-(gTime.Hours /4)*8)+gTime.Minutes / 30) & 1;
//-------------------------ПДД регулятор------------------
	  P_regDataFlow.input = Temperature[1];// входная температура
	  if (Weather_curve_en!=0) P_regDataFlow.set = ((int16_t)Weather_curve_value + Night_shift * Set_Night_shift)*10; else P_regDataFlow.set = (int16_t)Setpoint*10;//расчетное значение или константа
  	  if ((Priority_WWS!=0) && WWS_pump.out) P_regDataFlow.set = 30; //приоритет ГВС и необходимость нагрева ГВС- закрытие клапана
  	  P_regDataFlow.en = Power; // включение регулятора
//  	  P_regDataFlow.Ti = 10;
  	  PDD_PWM(&P_regDataFlow);

//------------------------защита от замерзания----------------
  	  if (Temperature[3]<30 && Temperature_outdoor<30 && Antifrost/* || Temperature[3]==-125*/) Boiler.out=1;
  	  if (Temperature[1]<30 && Temperature_outdoor<30 && Antifrost/* || Temperature[1]==-125*/) P_regDataFlow.up=1, P_regDataFlow.down=0,Boiler.out=1;

//------------------------обработка выходов----------------
  	  HAL_GPIO_WritePin(GPIOB, Relay_1_Pin, Boiler.out);
  	  HAL_GPIO_WritePin(GPIOB, Relay_2_Pin, WWS_pump.out);
  	  HAL_GPIO_WritePin(GPIOB, Relay_3_Pin, P_regDataFlow.up);
  	  HAL_GPIO_WritePin(GPIOB, Relay_4_Pin, P_regDataFlow.down);

//------------------------определение ошибок----------------
  	code_error.T1_H=500;
  	code_error.T2_H=900;
  	code_error.T3_H=650;
  	code_error.T4_H=990;
  	error=func_error(&code_error);

  //------------------------переключение страниц----------------
  	if (key.key_down_rise && edit==0) page++;
  	if (key.key_up_rise && edit==0) page--;

  	if (page==255) page=10;
  	if (page==11) page=0;

  //------------------------режим редактирования----------------
  	if (key.key_left>150 && edit==0 && page!=0 && key.key_right>150) edit=1, edit_string = 0, key.key_left=0, func_key(&key);
  	if (key.key_right>150 && edit==1 && key.key_left>150) edit=0, key.key_left=0, func_key(&key);

  	//-----------------включение прибора----------------
  	if (key.key_down>3000 && Power==0) page=0, Power=1, key.key_down=0, func_key(&key), Flash_memory_write(); //запись нужна для сохранения состояния прибора
  	if (key.key_down>3000 && Power==1 && edit==0) Power=0, key.key_down=0, func_key(&key), Flash_memory_write(); //запись нужна для сохранения состояния прибора
  	if (Power==0) page=100;

  	LCD_func(page);


    }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  LL_FLASH_SetLatency(LL_FLASH_LATENCY_2);

   if(LL_FLASH_GetLatency() != LL_FLASH_LATENCY_2)
  {
    Error_Handler();
  }
  LL_RCC_HSE_Enable();

   /* Wait till HSE is ready */
  while(LL_RCC_HSE_IsReady() != 1)
  {

  }

  LL_PWR_EnableBkUpAccess();

  if ( LL_RCC_LSE_IsReady() != 1)   //если кварц часовой не запущен
  {
	  LL_RCC_ForceBackupDomainReset();
	  LL_RCC_ReleaseBackupDomainReset();
	  LL_RCC_LSE_Enable();
  }
   /* Wait till LSE is ready */
  while(LL_RCC_LSE_IsReady() != 1)
  {

  }
  LL_RCC_SetRTCClockSource(LL_RCC_RTC_CLKSOURCE_LSE);
  LL_RCC_EnableRTC();
  LL_RCC_PLL_ConfigDomain_SYS(LL_RCC_PLLSOURCE_HSE_DIV_1, LL_RCC_PLL_MUL_9);
  LL_RCC_PLL_Enable();

   /* Wait till PLL is ready */
  while(LL_RCC_PLL_IsReady() != 1)
  {

  }
  LL_RCC_SetAHBPrescaler(LL_RCC_SYSCLK_DIV_1);
  LL_RCC_SetAPB1Prescaler(LL_RCC_APB1_DIV_2);
  LL_RCC_SetAPB2Prescaler(LL_RCC_APB2_DIV_1);
  LL_RCC_SetSysClkSource(LL_RCC_SYS_CLKSOURCE_PLL);



   /* Wait till System clock is ready */
  while(LL_RCC_GetSysClkSource() != LL_RCC_SYS_CLKSOURCE_STATUS_PLL)
  {

  }
  LL_SetSystemCoreClock(72000000);

   /* Update the time base */
  if (HAL_InitTick (TICK_INT_PRIORITY) != HAL_OK)
  {
    Error_Handler();
  };
}

/**
  * @brief I2C2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C2_Init(void)
{

  /* USER CODE BEGIN I2C2_Init 0 */

  /* USER CODE END I2C2_Init 0 */

  /* USER CODE BEGIN I2C2_Init 1 */

  /* USER CODE END I2C2_Init 1 */
  hi2c2.Instance = I2C2;
  hi2c2.Init.ClockSpeed = 400000;
  hi2c2.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c2.Init.OwnAddress1 = 0;
  hi2c2.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c2.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c2.Init.OwnAddress2 = 0;
  hi2c2.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c2.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C2_Init 2 */

  /* USER CODE END I2C2_Init 2 */

}

/**
  * @brief RTC Initialization Function
  * @param None
  * @retval None
  */
static void MX_RTC_Init(void)
{

  /* USER CODE BEGIN RTC_Init 0 */

  /* USER CODE END RTC_Init 0 */

//  RTC_TimeTypeDef sTime = {0};
//  RTC_DateTypeDef DateToUpdate = {0};

  /* USER CODE BEGIN RTC_Init 1 */

  /* USER CODE END RTC_Init 1 */
  /** Initialize RTC Only
  */
  hrtc.Instance = RTC;
  hrtc.Init.AsynchPrediv = RTC_AUTO_1_SECOND;
  hrtc.Init.OutPut = RTC_OUTPUTSOURCE_ALARM;
//  if (HAL_RTC_Init(&hrtc) != HAL_OK)
//  {
//    Error_Handler();
//  }

  /* USER CODE BEGIN Check_RTC_BKUP */

  /* USER CODE END Check_RTC_BKUP */

  /** Initialize RTC and set the Time and Date
  */
//  sTime.Hours = 8;
//  sTime.Minutes = 0;
//  sTime.Seconds = 0;

//  if (HAL_RTC_SetTime(&hrtc, &sTime, RTC_FORMAT_BIN) != HAL_OK)
//  {
//    Error_Handler();
//  }
//  DateToUpdate.WeekDay = RTC_WEEKDAY_MONDAY;
//  DateToUpdate.Month = RTC_MONTH_JUNE;
//  DateToUpdate.Date = 23;
//  DateToUpdate.Year = 21;

//  if (HAL_RTC_SetDate(&hrtc, &DateToUpdate, RTC_FORMAT_BIN) != HAL_OK)
//  {
//    Error_Handler();
//  }
  /* USER CODE BEGIN RTC_Init 2 */

  /* USER CODE END RTC_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 64;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 65534;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel4_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel4_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel4_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, Relay_4_Pin|Relay_3_Pin|Relay_2_Pin|Relay_1_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : PC13 */
  GPIO_InitStruct.Pin = GPIO_PIN_13;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PA0 PA1 PA2 PA3
                           PA11 PA12 PA15 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3
                          |GPIO_PIN_11|GPIO_PIN_12|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : Key_DOWN_Pin Key_LEFT_Pin Key_RIGHT_Pin */
  GPIO_InitStruct.Pin = Key_UP_Pin|Key_LEFT_Pin|Key_RIGHT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : Temp_1_Pin Temp_4_Pin Temp_3_Pin Temp_2_Pin */
  GPIO_InitStruct.Pin = Temp_1_Pin|Temp_4_Pin|Temp_3_Pin|Temp_2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB0 PB2 PB3 PB4
                           PB5 PB6 PB7 PB8
                           PB9 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4
                          |GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8
                          |GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : Key_UP_Pin */
  GPIO_InitStruct.Pin = Key_DOWN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(Key_DOWN_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : Relay_4_Pin Relay_3_Pin Relay_2_Pin Relay_1_Pin */
  GPIO_InitStruct.Pin = Relay_4_Pin|Relay_3_Pin|Relay_2_Pin|Relay_1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */
void LCD_func (uint16_t page_num)
{

	const char *string_open[] = {"Вiдкр.", "Откр.", "Open"};
	const char *string_close[] = {"Зачин.", "Закр.", "Close"};
	const char *string_stop[] = {"Стоп", "Стоп", "Stop"};
	const char *string_pause[] = {"Пауза", "Пауза", "Pause"};
	const char *string_on[] = {"Вкл.", "Вкл.", "On"};
	const char *string_off[] = {"Вимк.", "Выкл.", "Off"};

	const char *weekday_symbol_[] = {"Вс","Пн", "Вт", "Ср", "Чт", "Пт", "Сб"};
	const char *string0_1[] = {"Вулиця     ", "Улица      ", "Outdoor    "};//
	const char *string0_2[] = {"Подача     ", "Подача     ", "Flow       "};
  const char *string0_3_1[] = {"ГВС        ", "ГВС        ", "WWS        "};
  const char *string0_3_2[] = {"Зворотня   ", "Обратка    ", "Return     "};
	const char *string0_4[] = {"Нагрiвач   ", "Нагреват.  ", "Heater     "};

	const char *string1_1[]   = {"Керування    ", "Управление    ", "Control      "};
	const char *string1_2[]   = {"Регулятор    ", "Регулятор     ", "Regulator    "};
	const char *string1_3[]   = {"Нагрiвач     ", "Нагреват.     ", "Heater       "};
	const char *string1_4[]   = {"Пiдвищення   ", "Повышение     ", "Rise         "};
	const char *string1_5[]   = {"Крива  ", "Кривая  ", "Schedule"};
	const char *string1_6[]   = {"Уставка", "Уставка", "Setpoint"};

	const char *string2_1[]   = {"Гаряча вода", "Горячая вода", "Warm water"};
	const char *string2_2[]   = {"Нагрiв        ", "Нагрев        ", "Heating      "};
	const char *string2_3[]   = {"Завдання      ", "Задание       ", "Setting      "};
	const char *string2_4[]   = {"Гiстерезiс    ", "Гистерезис    ", "Hyst.        "};
	const char *string2_5[]   = {"Прiорiтет     ", "Приоритет     ", "Priority     "};
	const char *string2_6[]   = {"Пiдвищення    ", "Повышение     ", "Rise         "};
	const char *string2_7[]   = {"Насос         ", "Насос         ", "Pump         "};

	const char *string3_0[] = {"   Крива", "  Кривая", "Schedule"};
	const char *string3_1[] = {"Розрахунок   ", "Расчет       ", "Calculation  "};
	const char *string3_2[] = {"Кiмн. темп   ", "Комн. темп   ", "T room       "};
	const char *string3_3[] = {"N здвиг      ", "N смещение   ", "N shift      "};
	const char *string3_4[] = {"S нахил      ", "S наклон     ", "S slope      "};
	const char *string3_5[] = {"Максимум T   ", "Максимум  T  ", "T maximum    "};
	const char *string3_6[] = {"Ноч зниження ", "Ноч пониж    ", "Night shift  "};
	const char *string3_7[] = {"Завдання", "Настройки  ", "Setting"};
	const char *string3_8[] = {"Т опалення    ", "Т отопления   ", "T heating     "};

	const char *string4_0[] = {"Нiчне зниження", "Ночное понижение  ", "   Night shift"};
	const char *string_weekday[][3] =
	{
		{"Недiля", "Воскресение", "Sunday"},
		{"Понедiлок", "Понедельник", "Monday"},
		{"Вiвторок", "Вторник", "Tuesday"},
		{"Середа", "Среда", "Wednesday"},
		{"Четвер", "Четверг", "Thursday"},
		{"П'ятниця", "Пятница", "Friday"},
		{"Субота", "Суббота", "Saturday"}
	};
	const char *string_week_short[][3] =
	{
		{"Нд", "Вс", "Su"},
		{"Пн", "Пн", "Mo"},
		{"Вт", "Вт", "Tu"},
		{"Ср", "Ср", "We"},
		{"Чт", "Чт", "Th"},
		{"Пт", "Пт", "Fr"},
		{"Сб", "Сб", "Sa"}

	};
	const char *string5_0[] = {"Налашт. клапану", "Настройка клапана", "  Valve tuning"};
  	const char *string5_1[] = {"Регулятор К  ", "Регулятор К  ", "Regulator K  "};
	const char *string5_2[] = {"Клапан час   ", "Клапан время ", "Valve time   "};
	const char *string5_3[] = {"Люфт         ", "Люфт         ", "Lag time     "};
	const char *string5_4[] = {"Мiн iмпульс  ", "Мин импульс  ", "Min impuls   "};
	const char *string5_5[] = {"Клапан       ", "Клапан       ", "Valve        "};
	const char *string5_6[] = {"Импульс      ", "Імпульс      ", "Impuls       "};

	const char *string6_0[] = {"Налаштування", "Настройки  ", "Setting"};
	const char *string6_1[] = {"Мова         ", "Язык         ", "Language     "};
	const char *string6_2[] = {"УКР", "РУС", "ENG"};
	const char *string6_3[] = {"Контраст", "Контраст", "Contrast"};
	const char *string6_4[] = {"Антизамерзання ", "Антизамерзание ", "Antifrost  "};

	const char *string7_0[] = {"Завдання часу", "Настройка времени", " Time setting"};
	const char *string7_1[] = {"Поточне", "Текущее", "Present"};
	const char *string7_2[] = {"Завдання", "Задание", "Setting"};
	const char *string7_3[] = {"Рiк(0-99", "Год(0-99", "Year(0-99)"};
  	const char *string7_4[] = {"Мiсяць", "Месяц ", "Month "};
  	const char *string7_5[] = {"Число ", "Число ", "Day   "};
	const char *string7_6[] = {"Година", "Час   ", "Hour  "};
	const char *string7_7[] = {"Мiнута", "Минута", "Minute"};
	const char *string7_8[] = {"Записати", "Записать", "Save"};

	const char *string8_0[] = {"Коррекцiя датчику", "Коррекция датчика", "Sensor correction"};
	const char *string8_1[] = {"Змiщення", "Смещение", "Оffset  "};
	const char *string8_2[] = {"Датчик ", "Датчик ", "Sensor "};


	const char *string9_0[] = {"Коррекцiя датчику", "Коррекция датчика", "Sensor correction"};
	const char *string9_1[] = {"Добуток   ", "Произведение", "Quotient   "};
	const char *string9_2[] = {"Датчик ", "Датчик ", "Sensor "};

	const char *string10_0[] = {"Конфигурацiя", "Конфигурация", "Сonfiguration"};
	const char *string10_1[] = {"Датчик S1   ", "Датчик S1   ", "Sensor S1   "};
	const char *string10_2[] = {"Датчик S2   ", "Датчик S2   ", "Sensor S2   "};
	const char *string10_3[] = {"Датчик S3   ", "Датчик S3   ", "Sensor S3   "};
	const char *string10_4[] = {"Датчик S4   ", "Датчик S4   ", "Sensor S4   "};

	const char *string100_0[] = {"ВИМКНЕНО", "ВЫКЛЮЧЕНО", "  OFF"};
	const char *string100_1[] = {"Натиснiть D", "Нажмите D", " Press D"};

  ssd1306_Fill(Black);
  HAL_RTC_GetTime(&hrtc, &gTime, RTC_FORMAT_BIN);
  HAL_RTC_GetDate(&hrtc, &gDate, RTC_FORMAT_BIN);



  switch (page)
  {

    case 0: //основной экран
    	//символ ошибки, ночь/день, время,
    	// дата
    	//
    	//температура 1
    	//температура 2
    	//температура 3
    	//температура 4
    	//
    	ssd1306_SetCursorPos(0, 0, Font_7x9);
    	if (error!=0 && (HAL_GetTick()%400 > 200))
    	{
        	ssd1306_WriteChar('!', Font_7x9, White);
    		ssd1306_WriteChar('E', Font_7x9, White);
    		ssd1306_WriteNum(error, 0, "", White);
    		//Blink = 0;
    	}
    	if (error!=0 && (HAL_GetTick()%400 <= 200))
    	{
        	ssd1306_WriteChar('!', Font_7x9, Black);
    		ssd1306_WriteChar('E', Font_7x9, Black);
    		ssd1306_WriteNum(error, 0, "", White);
    		//Blink = 1;
    	}
//    	ssd1306_WriteNum((int16_t)Temperature_error[0], 0, "", White);
//    	ssd1306_WriteChar(' ', Font_7x9, White);
//    	ssd1306_WriteNum((uint16_t)HAL_GetTick()%1000, 0, "", White);


//---------------символ ночного времени
    	ssd1306_SetCursorPos(8, 0, Font_7x9);
        if (Night_shift) //проверка на ночное понижение
        {
        	ssd1306_WriteChar(188, Font_7x9, White);
        }
        else
        	ssd1306_WriteChar(187, Font_7x9, White);


   	//время
    	ssd1306_SetCursorPos(10, 0, Font_7x9);
    	ssd1306_WriteString(string_week_short[gDate.WeekDay][lang], Font_7x9, White);
    	ssd1306_WriteChar(' ', Font_7x9, White);
    	if (gTime.Hours<10) ssd1306_WriteChar('0', Font_7x9, White);
    	ssd1306_WriteNum(gTime.Hours, 0, ":", White);
    	if (gTime.Minutes<10) ssd1306_WriteChar('0', Font_7x9, White);
    	ssd1306_WriteNum(gTime.Minutes, 0, "", White);


    	ssd1306_SetCursorPos(0, 2, Font_7x9);
    	ssd1306_WriteString(string0_1[lang], Font_7x9, White);

    	if (Temperature_visu[0]==0)
    	{
    		ssd1306_WriteString(string_off[lang], Font_7x9, White);
    	}
    	else if (Temperature_outdoor == -1250)
    	{
        	ssd1306_WriteString("CRC err", Font_7x9, White);
    	}
    	else
    	{
    		ssd1306_WriteNum(Temperature_outdoor, 1, celsium, White);
    	}

    	ssd1306_SetCursorPos(0, 3, Font_7x9);
    	ssd1306_WriteString(string0_2[lang], Font_7x9, White);
    	if (Temperature_visu[1]==0)
    	{
    		ssd1306_WriteString(string_off[lang], Font_7x9, White);
    	}
    	else if (Temperature[1] == -1250)
    	{
        	ssd1306_WriteString("CRC error", Font_7x9, White);
    	}
    	else
    	{
    		ssd1306_WriteNum(Temperature[1], 1, celsium, White);
    	}

    	ssd1306_SetCursorPos(0, 4, Font_7x9);
    	if(WWS_en!=0) ssd1306_WriteString(string0_3_1[lang], Font_7x9, White);
    	else ssd1306_WriteString(string0_3_2[lang], Font_7x9, White);
    	if (Temperature_visu[2]==0)
    	{
    		ssd1306_WriteString(string_off[lang], Font_7x9, White);
    	}
    	else if (Temperature[2] == -1250)
    	{
        	ssd1306_WriteString("CRC error", Font_7x9, White);
    	}
    	else
    	{
    		ssd1306_WriteNum(Temperature[2], 1, celsium, White);
    	}

    	ssd1306_SetCursorPos(0, 5, Font_7x9);
    	ssd1306_WriteString(string0_4[lang], Font_7x9, White);
    	if (Temperature_visu[3]==0)
    	{
    		ssd1306_WriteString(string_off[lang], Font_7x9, White);
    	}
    	else if (Temperature[3] == -1250)
    	{
        	ssd1306_WriteString("CRC error", Font_7x9, White);
    	}
    	else
    	{
    		ssd1306_WriteNum(Temperature[3], 1, celsium, White);
    	}

//    	ssd1306_SetCursorPos(0, 6, Font_7x9);

//    	uint16_t *adrr1 = (uint16_t *)0x0801FC00;
//    	ssd1306_WriteNum(HAL_RTCEx_BKUPRead(&hrtc, RTC_BKP_DR9), 0, "", White);
//    	ssd1306_WriteString(" ", Font_7x9, White);
//    	ssd1306_WriteNum(HAL_RTCEx_BKUPRead(&hrtc, RTC_BKP_DR10), 0, "", White);
//    	ssd1306_WriteNum(*(adrr1+2), 0, "", White);

    break;

    case 1: // управление индикация


    	ssd1306_SetCursorPos(4, 0, Font_7x9);
    	ssd1306_WriteString(string1_1[lang], Font_7x9, White);

    	ssd1306_SetCursorPos(0, 2, Font_7x9);
    	ssd1306_WriteString(string1_2[lang], Font_7x9, White);
        if (Weather_curve_en==0)
        {
        	ssd1306_WriteString(string1_6[lang], Font_7x9, !(edit!=0 && edit_string == 0));
        }
        else   	ssd1306_WriteString(string1_5[lang], Font_7x9, !(edit!=0 && edit_string == 0));

    	ssd1306_SetCursorPos(0, 3, Font_7x9);
    	ssd1306_WriteString(string1_3[lang], Font_7x9, White);
        if (Boiler.out!=0)
        {
        	ssd1306_WriteString(string_on[lang], Font_7x9, White);
        }
        else
        	ssd1306_WriteString(string_off[lang], Font_7x9, White);
    	ssd1306_SetCursorPos(0, 4, Font_7x9);
    	ssd1306_WriteString(string1_4[lang], Font_7x9, White);
		ssd1306_WriteNum(Boiler.hyst, 0, celsium, !(edit!=0 && edit_string == 1));
		ssd1306_SetCursorPos(0, 5, Font_7x9);
/*
        if (Boiler_en==0)
        {
        	ssd1306_WriteString(string1_6[lang], Font_7x9, !(edit!=0 && edit_string == 0));
        }
        else   	ssd1306_WriteString(string1_5[lang], Font_7x9, !(edit!=0 && edit_string == 0));
*/


//-----------------------------------------------------------------------------------------------
    	if (edit!=0 && key.key_left_rise) edit_string++;
    	if (edit!=0 && key.key_right_rise) edit_string--;
    	if (edit_string==255) edit_string++;
    	if (edit_string==2) edit_string--;

    	if (edit!=0 && edit_string==0 && key.key_up_rise) Weather_curve_en=1;
    	if (edit!=0 && edit_string==0 && key.key_down_rise) Weather_curve_en=0;
    	if (edit!=0 && edit_string==1 && key.key_up_rise) Boiler.hyst++;
    	if (edit!=0 && edit_string==1 && key.key_down_rise) Boiler.hyst--;
    	if (edit!=0 && edit_string==1 && key.key_up>1000) Boiler.hyst++;
    	if (edit!=0 && edit_string==1 && key.key_down>1000) Boiler.hyst--;
//-----------------------------------------------------------------------------------------------


    break;


    case 2://ГВС

    //-----------------------------------------------------------------------------------------------
    		if (edit!=0 && key.key_left_rise) edit_string++;
    		if (edit!=0 && key.key_right_rise) edit_string--;
    		if (edit_string==255) edit_string++;
    		if (WWS_en!=0) {if (edit_string==5) edit_string--;}
    		else {if (edit_string==1) edit_string--;}

        	if (edit!=0 && edit_string==0 && key.key_up_rise) WWS_en=1;
        	if (edit!=0 && edit_string==0 && key.key_down_rise) WWS_en=0;
        	if (edit!=0 && edit_string==1 && key.key_up_rise) Set_temp_WWS++;
        	if (edit!=0 && edit_string==1 && key.key_down_rise) Set_temp_WWS--;
        	if (edit!=0 && edit_string==1 && key.key_up>1000) Set_temp_WWS++;
        	if (edit!=0 && edit_string==1 && key.key_down>1000) Set_temp_WWS--;
        	if (edit!=0 && edit_string==2 && key.key_up_rise) Set_hyst_WWS++;
        	if (edit!=0 && edit_string==2 && key.key_down_rise) Set_hyst_WWS--;
        	if (edit!=0 && edit_string==2 && key.key_up>1000) Set_hyst_WWS++;
        	if (edit!=0 && edit_string==2 && key.key_down>1000) Set_hyst_WWS--;
        	if (edit!=0 && edit_string==3 && key.key_up_rise) Priority_WWS=1;
        	if (edit!=0 && edit_string==3 && key.key_down_rise) Priority_WWS=0;
        	if (edit!=0 && edit_string==4 && key.key_up_rise) Boiler_WWS++;
        	if (edit!=0 && edit_string==4 && key.key_down_rise) Boiler_WWS--;
        	if (edit!=0 && edit_string==4 && key.key_up>1000) Boiler_WWS++;
        	if (edit!=0 && edit_string==4 && key.key_down>1000) Boiler_WWS--;

        	ssd1306_SetCursorPos(4, 0, Font_7x9);
        	ssd1306_WriteString(string2_1[lang], Font_7x9, White);
        	ssd1306_SetCursorPos(0, 1, Font_7x9);
        	ssd1306_WriteString(string2_2[lang], Font_7x9, White);
			if (WWS_en!=0) ssd1306_WriteString(string_on[lang], Font_7x9, !(edit!=0 && edit_string == 0));
			else ssd1306_WriteString(string_off[lang], Font_7x9, !(edit!=0 && edit_string == 0));
        	if (WWS_en!=0)
        	{
				ssd1306_SetCursorPos(0, 2, Font_7x9);
	        	ssd1306_WriteString(string2_3[lang], Font_7x9, White);
				ssd1306_WriteNum(Set_temp_WWS, 0, celsium, !(edit!=0 && edit_string == 1));
				ssd1306_SetCursorPos(0, 3, Font_7x9);
				ssd1306_WriteString(string2_4[lang], Font_7x9, White);
				ssd1306_WriteNum(Set_hyst_WWS, 0, celsium, !(edit!=0 && edit_string == 2));
				ssd1306_SetCursorPos(0, 4, Font_7x9);
				ssd1306_WriteString(string2_5[lang], Font_7x9, White);
				if (Priority_WWS!=0) ssd1306_WriteString(string_on[lang], Font_7x9, !(edit!=0 && edit_string == 3));
				else ssd1306_WriteString(string_off[lang], Font_7x9, !(edit!=0 && edit_string == 3));
				ssd1306_SetCursorPos(0, 5, Font_7x9);
				ssd1306_WriteString(string2_6[lang], Font_7x9, White);
				ssd1306_WriteNum(Boiler_WWS, 0, celsium, !(edit!=0 && edit_string == 4));
				ssd1306_SetCursorPos(0, 6, Font_7x9);
		    	ssd1306_WriteString(string2_7[lang], Font_7x9, White);
		        if (WWS_pump.out!=0)
		        {
		        	ssd1306_WriteString(string_on[lang], Font_7x9, White);
		        }
		        else   	ssd1306_WriteString(string_off[lang], Font_7x9, White);
        	}
    break;

    case 3://кривые


    	if (Weather_curve_en!=0)
    	{
			// настройка кривой (пользователь)
			//Задание
			//Температура в помещении
			//Смещение кривой
			//Наклон кривой
			//Максимальная температура
			//Ночное смещение
	//-----------------------------------------------------------------------------------------------
			if (edit!=0 && key.key_left_rise) edit_string++;
			if (edit!=0 && key.key_right_rise) edit_string--;
			if (edit_string==255) edit_string++;
			if (edit_string==5) edit_string--;

			if (edit!=0 && edit_string==0 && key.key_up_rise) Set_T_room++;
			if (edit!=0 && edit_string==0 && key.key_down_rise) Set_T_room--;
			if (edit!=0 && edit_string==0 && key.key_up>1000) Set_T_room++;
			if (edit!=0 && edit_string==0 && key.key_down>1000) Set_T_room--;
			if (edit!=0 && edit_string==1 && key.key_up_rise) Set_N_graph_shift++;
			if (edit!=0 && edit_string==1 && key.key_down_rise) Set_N_graph_shift--;
			if (edit!=0 && edit_string==1 && key.key_up>1000) Set_N_graph_shift++;
			if (edit!=0 && edit_string==1 && key.key_down>1000) Set_N_graph_shift--;
			if (edit!=0 && edit_string==2 && key.key_up_rise) S_graph_slope++;
			if (edit!=0 && edit_string==2 && key.key_down_rise) S_graph_slope--;
			if (edit!=0 && edit_string==2 && key.key_up>1000) S_graph_slope++;
			if (edit!=0 && edit_string==2 && key.key_down>1000) S_graph_slope--;
			if (edit!=0 && edit_string==3 && key.key_up_rise) Set_T_max++;
			if (edit!=0 && edit_string==3 && key.key_down_rise) Set_T_max--;
			if (edit!=0 && edit_string==3 && key.key_up>1000) Set_T_max++;
			if (edit!=0 && edit_string==3 && key.key_down>1000) Set_T_max--;
			if (edit!=0 && edit_string==4 && key.key_up_rise) Set_Night_shift++;
			if (edit!=0 && edit_string==4 && key.key_down_rise) Set_Night_shift--;
			if (edit!=0 && edit_string==4 && key.key_up>1000) Set_Night_shift++;
			if (edit!=0 && edit_string==4 && key.key_down>1000) Set_Night_shift--;

	//-----------------------------------------------------------------------------------------------
			ssd1306_SetCursorPos(5, 0, Font_7x9);
			ssd1306_WriteString(string3_0[lang], Font_7x9, White);

			ssd1306_SetCursorPos(0, 1, Font_7x9);
			ssd1306_WriteString(string3_1[lang], Font_7x9, White);
			ssd1306_WriteNum ((uint8_t)Weather_curve_value, 0, celsium, White);

			ssd1306_SetCursorPos(0, 2, Font_7x9);
			ssd1306_WriteString(string3_2[lang], Font_7x9, White);
			ssd1306_WriteNum(Set_T_room, 0, celsium, !(edit!=0 && edit_string == 0));

			ssd1306_SetCursorPos(0, 3, Font_7x9);
			ssd1306_WriteString(string3_3[lang], Font_7x9, White);
			ssd1306_WriteNum(Set_N_graph_shift, 0, celsium, !(edit!=0 && edit_string == 1));

			ssd1306_SetCursorPos(0, 4, Font_7x9);
			ssd1306_WriteString(string3_4[lang], Font_7x9, White);
			ssd1306_WriteNum(S_graph_slope, 1,"", !(edit!=0 && edit_string == 2));

			ssd1306_SetCursorPos(0, 5, Font_7x9);
			ssd1306_WriteString(string3_5[lang], Font_7x9, White);
			ssd1306_WriteNum(Set_T_max, 0, celsium, !(edit!=0 && edit_string == 3));

			ssd1306_SetCursorPos(0, 6, Font_7x9);
			ssd1306_WriteString(string3_6[lang], Font_7x9, White);
			ssd1306_WriteNum(Set_Night_shift, 0, celsium, !(edit!=0 && edit_string == 4));
    	}
    	else
    	{
			ssd1306_SetCursorPos(4, 0, Font_7x9);
			ssd1306_WriteString(string3_7[lang], Font_7x9, White);

			ssd1306_SetCursorPos(0, 1, Font_7x9);
			ssd1306_WriteString(string3_8[lang], Font_7x9, White);
			ssd1306_WriteNum(Setpoint, 0, celsium, !(edit!=0 && edit_string == 0));
			//------------------------------------------------

			if (edit!=0 && edit_string==0 && key.key_up_rise) Setpoint++;
			if (edit!=0 && edit_string==0 && key.key_down_rise) Setpoint--;
			if (edit!=0 && edit_string==0 && key.key_up>1000) Setpoint++;
			if (edit!=0 && edit_string==0 && key.key_down>1000) Setpoint--;
    	}
    break;

    case 4: // ночное время (пользователь)
    	//ПН
    	//ВТ
    	//СР
    	//ЧТ
    	//ПТ
    	//СБ
    	//ВС
		if (edit==0 && key.key_left_rise) Set_Weekday++;
		if (edit==0 && key.key_right_rise) Set_Weekday--;
		if (Set_Weekday==255) Set_Weekday++;
		if (Set_Weekday==7) Set_Weekday--;

    	ssd1306_SetCursorPos(3, 0, Font_7x9);
    	ssd1306_WriteString(string4_0[lang], Font_7x9, White);
    	ssd1306_SetCursorPos(0, 2, Font_7x9);
    	ssd1306_WriteString(string_weekday[Set_Weekday][lang], Font_7x9, White);

//-----------------------------------------------------------------------------------------------
		if (edit!=0 && key.key_left_rise) edit_string++;
		if (edit!=0 && key.key_right_rise) edit_string--;
		if (edit_string==255) edit_string++;
		if (edit_string==48) edit_string--;
		if (edit!=0 && key.key_up_rise) SetBit (Night_shift_time[Set_Weekday][edit_string/8], edit_string%8);
		if (edit!=0 && key.key_down_rise) ClearBit (Night_shift_time[Set_Weekday][edit_string/8], edit_string%8);
//-------------------------------------------------------------------------------ц----------------

    	ssd1306_SetCursorPos(0, 3, Font_7x9);
    	ssd1306_WriteString("0       6       12", Font_7x9, White);
    	ssd1306_SetCursorPos(0, 4, Font_7x9);
    	uint8_t i=0;
    	for (;i<24;i++)
    	{
    		ssd1306_SetCursor (i*5+4, 4*9);
			if (edit!=0 && i==edit_string && (HAL_GetTick()%1000>500)) ssd1306_WriteChar (' ', Font_7x9, White);
			else if (TestBit((Night_shift_time[Set_Weekday][i/8]),i%8)) ssd1306_WriteChar (190, Font_7x9, White);
			else ssd1306_WriteChar (189, Font_7x9, White);

    	}
    	ssd1306_SetCursorPos(0, 5, Font_7x9);
    	ssd1306_WriteString("12      18      24", Font_7x9, White);
    	ssd1306_SetCursorPos(0, 6, Font_7x9);

    	for (i=24;i<48;i++)
    	{
    		ssd1306_SetCursor ((i-24)*5+4, 6*9);
			if (edit!=0 && i==edit_string && (HAL_GetTick()%1000>500)) ssd1306_WriteChar (' ', Font_7x9, White);
			else if (TestBit((Night_shift_time[Set_Weekday][i/8]),i%8)) ssd1306_WriteChar (190, Font_7x9, White);
			else ssd1306_WriteChar (189, Font_7x9, White);
    	}

		break;

    case 5: // настройки клапана

//------------------------------------------------------------------------
    	if (edit!=0 && key.key_left_rise) edit_string++;
		if (edit!=0 && key.key_right_rise) edit_string--;
		if (edit_string==255) edit_string++;
		if (edit_string==5) edit_string--;

		if (edit!=0 && edit_string==0 && (key.key_up > 1000)) P_regDataFlow.K++;
		if (edit!=0 && edit_string==0 && key.key_up_rise) P_regDataFlow.K++;
		if (edit!=0 && edit_string==0 && (key.key_down > 1000)) P_regDataFlow.K--;
		if (edit!=0 && edit_string==0 && key.key_down_rise) P_regDataFlow.K--;

		if (edit!=0 && edit_string==1 && (key.key_up > 1000)) P_regDataFlow.valve_time++;
		if (edit!=0 && edit_string==1 && key.key_up_rise) P_regDataFlow.valve_time++;
		if (edit!=0 && edit_string==1 && (key.key_down > 1000)) P_regDataFlow.valve_time--;
		if (edit!=0 && edit_string==1 && key.key_down_rise) P_regDataFlow.valve_time--;

		if (edit!=0 && edit_string==2 && key.key_up_rise) P_regDataFlow.lag_valve_time++;
		if (edit!=0 && edit_string==2 && key.key_down_rise) P_regDataFlow.lag_valve_time--;
		if (edit!=0 && edit_string==2 && key.key_up>1000) P_regDataFlow.lag_valve_time++;
		if (edit!=0 && edit_string==2 && key.key_down>1000) P_regDataFlow.lag_valve_time--;

		if (edit!=0 && edit_string==3 && key.key_up_rise) P_regDataFlow.min_valve_time++;
		if (edit!=0 && edit_string==3 && key.key_down_rise) P_regDataFlow.min_valve_time--;
		if (edit!=0 && edit_string==3 && key.key_up>1000) P_regDataFlow.min_valve_time++;
		if (edit!=0 && edit_string==3 && key.key_down>1000) P_regDataFlow.min_valve_time--;



//-----------------------------------------------------------------------------------------------
    	ssd1306_SetCursorPos(2, 0, Font_7x9);
    	ssd1306_WriteString(string5_0[lang], Font_7x9, White);
    	ssd1306_SetCursorPos(0, 1, Font_7x9);
    	ssd1306_WriteString(string5_1[lang], Font_7x9, White);
    	ssd1306_WriteNum(P_regDataFlow.K, 1, "", !(edit!=0 && edit_string == 0));
    	ssd1306_SetCursorPos(0, 2, Font_7x9);
    	ssd1306_WriteString(string5_2[lang], Font_7x9, White);
    	ssd1306_WriteNum(P_regDataFlow.valve_time, 0, "s", !(edit!=0 && edit_string == 1));
    	ssd1306_SetCursorPos(0, 3, Font_7x9);
    	ssd1306_WriteString(string5_3[lang], Font_7x9, White);
    	ssd1306_WriteNum(P_regDataFlow.lag_valve_time, 0, "ms", !(edit!=0 && edit_string == 2));
    	ssd1306_SetCursorPos(0, 4, Font_7x9);
    	ssd1306_WriteString(string5_4[lang], Font_7x9, White);
    	ssd1306_WriteNum(P_regDataFlow.min_valve_time, 0, "ms", !(edit!=0 && edit_string == 3));
    	ssd1306_SetCursorPos(0, 5, Font_7x9);
    	ssd1306_WriteString(string5_5[lang], Font_7x9, White);
        if (P_regDataFlow.up!=0)
         {
         	ssd1306_WriteString(string_open[lang], Font_7x9, White);
         }
         else if (P_regDataFlow.down!=0)
         {
         	ssd1306_WriteString(string_close[lang], Font_7x9, White);
         }
         else
         	ssd1306_WriteString(string_pause[lang], Font_7x9, White);
        ssd1306_SetCursorPos(0, 6, Font_7x9);
        ssd1306_WriteString(string5_6[lang], Font_7x9, White);
        ssd1306_WriteNum((int16_t)P_regDataFlow.imp_time, 0, "ms", White);


    break;

    case 6: // Настройки общие
    	//СБ
    	//ВС
    	//

    	if (edit!=0 && key.key_left_rise) edit_string++;
		if (edit!=0 && key.key_right_rise) edit_string--;
		if (edit_string==255) edit_string++;
		if (edit_string==3) edit_string--;

		if (edit!=0 && edit_string==0 && key.key_up_rise) lang++;
		if (edit!=0 && edit_string==0 && key.key_down_rise) lang--;
		if (edit!=0 && edit_string==1 && key.key_up_rise) Contrast++;
		if (edit!=0 && edit_string==1 && key.key_down_rise) Contrast--;
		if (edit!=0 && edit_string==2 && key.key_up_rise) Antifrost = 1;
		if (edit!=0 && edit_string==2 && key.key_down_rise) Antifrost = 0;

    	ssd1306_SetCursorPos(5, 0, Font_7x9);
    	ssd1306_WriteString(string6_0[lang], Font_7x9, White);
    	ssd1306_SetCursorPos(0, 2, Font_7x9);
    	ssd1306_WriteString(string6_1[lang], Font_7x9, White);
    	ssd1306_SetCursorPos(15, 2, Font_7x9);
    	ssd1306_WriteString(string6_2[lang], Font_7x9, !(edit!=0 && edit_string == 0));
    	ssd1306_SetCursorPos(0, 3, Font_7x9);
    	ssd1306_WriteString(string6_3[lang], Font_7x9, White);
    	ssd1306_SetCursorPos(15, 3, Font_7x9);
    	ssd1306_WriteNum(Contrast, 0, "", !(edit!=0 && edit_string == 1));
    	ssd1306_SetContrast(Contrast*25);
    	ssd1306_SetCursorPos(0, 4, Font_7x9);
    	ssd1306_WriteString(string6_4[lang], Font_7x9, White);
    	ssd1306_SetCursorPos(15, 4, Font_7x9);
        if (Antifrost!=0)
        {
        	ssd1306_WriteString(string_on[lang], Font_7x9, !(edit!=0 && edit_string == 2));
        }
        else	ssd1306_WriteString(string_off[lang], Font_7x9, !(edit!=0 && edit_string == 2));

        break;

    case 7: // Настройки времени
    	//
//-----------------------------------------------------------------------------------------------
		if (edit!=0 && key.key_left_rise) edit_string++;
		if (edit!=0 && key.key_right_rise) edit_string--;
		if (edit_string==255) edit_string++;
		if (edit_string==7) edit_string--;

		if (edit!=0 && edit_string==0 && key.key_up_rise) Set_gTime.Hours++;
		if (edit!=0 && edit_string==0 && key.key_down_rise) Set_gTime.Hours--;
		if (edit!=0 && edit_string==0 && key.key_up>1000) Set_gTime.Hours++;
		if (edit!=0 && edit_string==0 && key.key_down>1000) Set_gTime.Hours--;
		if (Set_gTime.Hours>240) Set_gTime.Hours = 0;
		if (Set_gTime.Hours>23) Set_gTime.Hours = 23;
		if (edit!=0 && edit_string==1 && key.key_up_rise) Set_gTime.Minutes++;
		if (edit!=0 && edit_string==1 && key.key_down_rise) Set_gTime.Minutes--;
		if (edit!=0 && edit_string==1 && key.key_up>1000) Set_gTime.Minutes++;
		if (edit!=0 && edit_string==1 && key.key_down>1000) Set_gTime.Minutes--;
		if (Set_gTime.Minutes>240) Set_gTime.Minutes = 0;
		if (Set_gTime.Minutes>59) Set_gTime.Minutes = 59;
		if (edit!=0 && edit_string==2 && key.key_up_rise) Set_gTime.Seconds++;
		if (edit!=0 && edit_string==2 && key.key_down_rise) Set_gTime.Seconds--;
		if (edit!=0 && edit_string==2 && key.key_up>1000) Set_gTime.Seconds++;
		if (edit!=0 && edit_string==2 && key.key_down>1000) Set_gTime.Seconds--;
		if (Set_gTime.Seconds>240) Set_gTime.Seconds = 0;
		if (Set_gTime.Seconds>59) Set_gTime.Seconds = 59;
		if (edit!=0 && edit_string==3 && key.key_up_rise) Set_gDate.Date++;
		if (edit!=0 && edit_string==3 && key.key_down_rise) Set_gDate.Date--;
		if (edit!=0 && edit_string==3 && key.key_up>1000) Set_gDate.Date++;
		if (edit!=0 && edit_string==3 && key.key_down>1000) Set_gDate.Date--;
		if (Set_gDate.Date>240) Set_gDate.Date = 1;
		if (Set_gDate.Date>60) Set_gDate.Date = 31; // под каждый месяц свое количество дней
		if (edit!=0 && edit_string==4 && key.key_up_rise) Set_gDate.Month++;
		if (edit!=0 && edit_string==4 && key.key_down_rise) Set_gDate.Month--;
		if (edit!=0 && edit_string==4 && key.key_up>1000) Set_gDate.Month++;
		if (edit!=0 && edit_string==4 && key.key_down>1000) Set_gDate.Month--;
		if (Set_gDate.Month>240) Set_gDate.Month = 1;
		if (Set_gDate.Month>60) Set_gDate.Month = 12;
		if (edit!=0 && edit_string==5 && key.key_up_rise) Set_gDate.Year++;
		if (edit!=0 && edit_string==5 && key.key_down_rise) Set_gDate.Year--;
		if (edit!=0 && edit_string==5 && key.key_up>1000) Set_gDate.Year++;
		if (edit!=0 && edit_string==5 && key.key_down>1000) Set_gDate.Year--;
		if (Set_gDate.Year>240) Set_gDate.Year = 0;
		if (Set_gDate.Year>100) Set_gDate.Year = 99;
		if (edit!=0 && edit_string==6 && key.key_up_rise)
		{
			  if (HAL_RTC_SetTime(&hrtc, &Set_gTime, RTC_FORMAT_BIN) != HAL_OK)
			  {
			    Error_Handler();
			  }

			  if (HAL_RTC_SetDate(&hrtc, &Set_gDate, RTC_FORMAT_BIN) != HAL_OK)
			  {
			    Error_Handler();
			  }


			  uint32_t JDN = RTC_GetRTC_Counter(&Set_gDate, &Set_gTime);
			  //----------------сохраняем глобальное время-------------------
			  HAL_RTCEx_BKUPWrite(&hrtc, RTC_BKP_DR9, JDN >> 16);
			  HAL_RTCEx_BKUPWrite(&hrtc, RTC_BKP_DR10, JDN & 0x0000FFFF);

			  BKUPTimeSave = 0;
			  BKUPData = JDN;
		}

		if (edit==0)
		{
			Set_gTime.Hours = gTime.Hours;
			Set_gTime.Minutes = gTime.Minutes;
		}
//-----------------------------------------------------------------------------------------------
    	ssd1306_SetCursorPos(3, 0, Font_7x9);
    	ssd1306_WriteString(string7_0[lang], Font_7x9, White);
    	ssd1306_SetCursorPos(0, 1, Font_7x9);
    	ssd1306_WriteString(string7_1[lang], Font_7x9, White);
    	ssd1306_SetCursorPos(10, 1, Font_7x9);
    	ssd1306_WriteString(string7_2[lang], Font_7x9, White);

    	ssd1306_SetCursorPos(0, 2, Font_7x9);
    	if (gTime.Hours<10) ssd1306_WriteChar('0', Font_7x9, White);
    	ssd1306_WriteNum(gTime.Hours, 0, ":", White);
    	if (gTime.Minutes<10) ssd1306_WriteChar('0', Font_7x9, White);
    	ssd1306_WriteNum(gTime.Minutes, 0, ":", White);
    	if (gTime.Seconds<10) ssd1306_WriteChar('0', Font_7x9, White);
    	ssd1306_WriteNum(gTime.Seconds, 0, "", White);

    	ssd1306_SetCursorPos(10, 2, Font_7x9);
    	if (Set_gTime.Hours<10) ssd1306_WriteChar('0', Font_7x9, !(edit!=0 && edit_string == 0));
    	ssd1306_WriteNum(Set_gTime.Hours, 0, "", !(edit!=0 && edit_string == 0));
    	ssd1306_WriteChar(':', Font_7x9, White);
    	if (Set_gTime.Minutes<10) ssd1306_WriteChar('0', Font_7x9, !(edit!=0 && edit_string == 1));
    	ssd1306_WriteNum(Set_gTime.Minutes, 0, "", !(edit!=0 && edit_string == 1));
    	ssd1306_WriteChar(':', Font_7x9, White);
    	if (Set_gTime.Seconds<10) ssd1306_WriteChar('0', Font_7x9, !(edit!=0 && edit_string == 2));
    	ssd1306_WriteNum(Set_gTime.Seconds, 0, "", !(edit!=0 && edit_string == 2));

    	ssd1306_SetCursorPos(0, 3, Font_7x9);
    	if (gDate.Date<10) ssd1306_WriteChar('0', Font_7x9, White);
    	ssd1306_WriteNum(gDate.Date , 0, "-", White);
    	if (gDate.Month<10) ssd1306_WriteChar('0', Font_7x9, White);
    	ssd1306_WriteNum(gDate.Month, 0, "-", White);
    	if (gDate.Year<10) ssd1306_WriteChar('0', Font_7x9, White);
    	ssd1306_WriteNum(gDate.Year, 0, "", White);

    	ssd1306_SetCursorPos(10, 3, Font_7x9);
    	if (Set_gDate.Date<10) ssd1306_WriteChar('0', Font_7x9, !(edit!=0 && edit_string == 3));
    	ssd1306_WriteNum(Set_gDate.Date , 0, "", !(edit!=0 && edit_string == 3));
    	ssd1306_WriteChar('-', Font_7x9, White);
    	if (Set_gDate.Month<10) ssd1306_WriteChar('0', Font_7x9, !(edit!=0 && edit_string == 4));
    	ssd1306_WriteNum(Set_gDate.Month, 0, "", !(edit!=0 && edit_string == 4));
    	ssd1306_WriteChar('-', Font_7x9, White);
    	if (Set_gDate.Year<10) ssd1306_WriteChar('0', Font_7x9, !(edit!=0 && edit_string == 5));
    	ssd1306_WriteNum(Set_gDate.Year, 0, "", !(edit!=0 && edit_string == 5));

    	ssd1306_SetCursorPos(0, 4, Font_7x9);
    	ssd1306_WriteString(string_weekday[gDate.WeekDay][lang], Font_7x9, White);

    	ssd1306_SetCursorPos(0, 5, Font_7x9);
    	ssd1306_WriteString(string7_8[lang], Font_7x9, !(edit!=0 && edit_string == 6));
    break;

    case 8: //коррекция температуры (Tрасч = (Тизм-Dt)/K)

    	if (edit!=0 && key.key_left_rise) edit_string++;
		if (edit!=0 && key.key_right_rise) edit_string--;
		if (edit_string==255) edit_string++;
		if (edit_string==5) edit_string--;

		if (edit!=0 && edit_string==0 && key.key_up_rise) Summ_Temp[0]++;
		if (edit!=0 && edit_string==0 && key.key_down_rise) Summ_Temp[0]--;
		if (edit!=0 && edit_string==0 && key.key_up>1000) Summ_Temp[0]++;
		if (edit!=0 && edit_string==0 && key.key_down>1000) Summ_Temp[0]--;
		if (edit!=0 && edit_string==1 && key.key_up_rise) Summ_Temp[1]++;
		if (edit!=0 && edit_string==1 && key.key_down_rise) Summ_Temp[1]--;
		if (edit!=0 && edit_string==1 && key.key_up>1000) Summ_Temp[1]++;
		if (edit!=0 && edit_string==1 && key.key_down>1000) Summ_Temp[1]--;
		if (edit!=0 && edit_string==2 && key.key_up_rise) Summ_Temp[2]++;
		if (edit!=0 && edit_string==2 && key.key_down_rise) Summ_Temp[2]--;
		if (edit!=0 && edit_string==2 && key.key_up>1000) Summ_Temp[2]++;
		if (edit!=0 && edit_string==2 && key.key_down>1000) Summ_Temp[2]--;
		if (edit!=0 && edit_string==3 && key.key_up_rise) Summ_Temp[3]++;
		if (edit!=0 && edit_string==3 && key.key_down_rise) Summ_Temp[3]--;
		if (edit!=0 && edit_string==3 && key.key_up>1000) Summ_Temp[3]++;
		if (edit!=0 && edit_string==3 && key.key_down>1000) Summ_Temp[3]--;


    	ssd1306_SetCursorPos(1, 0, Font_7x9);
    	ssd1306_WriteString(string8_0[lang] , Font_7x9, White);
    	ssd1306_SetCursorPos(1, 1, Font_7x9);
    	ssd1306_WriteString(string8_1[lang] , Font_7x9, White);
    	ssd1306_SetCursorPos(0, 3, Font_7x9);
    	ssd1306_WriteString(string8_2[lang] , Font_7x9, White);
    	ssd1306_WriteString("1 " , Font_7x9, White);
    	ssd1306_WriteNum(Summ_Temp[0], 1, celsium, !(edit!=0 && edit_string == 0));
    	ssd1306_SetCursorPos(0, 4, Font_7x9);
    	ssd1306_WriteString(string8_2[lang] , Font_7x9, White);
    	ssd1306_WriteString("2 " , Font_7x9, White);
    	ssd1306_WriteNum(Summ_Temp[1], 1, celsium, !(edit!=0 && edit_string == 1));
    	ssd1306_SetCursorPos(0, 5, Font_7x9);
    	ssd1306_WriteString(string8_2[lang] , Font_7x9, White);
    	ssd1306_WriteString("3 " , Font_7x9, White);
    	ssd1306_WriteNum(Summ_Temp[2], 1, celsium, !(edit!=0 && edit_string == 2));
    	ssd1306_SetCursorPos(0, 6, Font_7x9);
    	ssd1306_WriteString(string8_2[lang] , Font_7x9, White);
    	ssd1306_WriteString("4 " , Font_7x9, White);
    	ssd1306_WriteNum(Summ_Temp[3], 1, celsium, !(edit!=0 && edit_string == 3));
        break;

    case 9: //коррекция температуры (Tрасч = (Тизм-Dt)/K)

    	if (edit!=0 && key.key_left_rise) edit_string++;
		if (edit!=0 && key.key_right_rise) edit_string--;
		if (edit_string==255) edit_string++;
		if (edit_string==5) edit_string--;

		if (edit!=0 && edit_string==0 && key.key_up_rise) Mul_Temp[0]++;
		if (edit!=0 && edit_string==0 && key.key_down_rise) Mul_Temp[0]--;
		if (edit!=0 && edit_string==0 && key.key_up>1000) Mul_Temp[0]++;
		if (edit!=0 && edit_string==0 && key.key_down>1000) Mul_Temp[0]--;
		if (edit!=0 && edit_string==1 && key.key_up_rise) Mul_Temp[1]++;
		if (edit!=0 && edit_string==1 && key.key_down_rise) Mul_Temp[1]--;
		if (edit!=0 && edit_string==1 && key.key_up>1000) Mul_Temp[1]++;
		if (edit!=0 && edit_string==1 && key.key_down>1000) Mul_Temp[1]--;
		if (edit!=0 && edit_string==2 && key.key_up_rise) Mul_Temp[2]++;
		if (edit!=0 && edit_string==2 && key.key_down_rise) Mul_Temp[2]--;
		if (edit!=0 && edit_string==2 && key.key_up>1000) Mul_Temp[2]++;
		if (edit!=0 && edit_string==2 && key.key_down>1000) Mul_Temp[2]--;
		if (edit!=0 && edit_string==3 && key.key_up_rise) Mul_Temp[3]++;
		if (edit!=0 && edit_string==3 && key.key_down_rise) Mul_Temp[3]--;
		if (edit!=0 && edit_string==3 && key.key_up>1000) Mul_Temp[3]++;
		if (edit!=0 && edit_string==3 && key.key_down>1000) Mul_Temp[3]--;
    	ssd1306_SetCursorPos(1, 0, Font_7x9);
    	ssd1306_WriteString(string9_0[lang] , Font_7x9, White);
    	ssd1306_SetCursorPos(1, 1, Font_7x9);
    	ssd1306_WriteString(string9_1[lang] , Font_7x9, White);
    	ssd1306_SetCursorPos(0, 3, Font_7x9);
    	ssd1306_WriteString(string9_2[lang] , Font_7x9, White);
    	ssd1306_WriteString("1 " , Font_7x9, White);
    	ssd1306_WriteNum(Mul_Temp[0], 3, "", !(edit!=0 && edit_string == 0));
    	ssd1306_SetCursorPos(0, 4, Font_7x9);
    	ssd1306_WriteString(string9_2[lang] , Font_7x9, White);
    	ssd1306_WriteString("2 " , Font_7x9, White);
    	ssd1306_WriteNum(Mul_Temp[1], 3, "", !(edit!=0 && edit_string == 1));
    	ssd1306_SetCursorPos(0, 5, Font_7x9);
    	ssd1306_WriteString(string9_2[lang] , Font_7x9, White);
    	ssd1306_WriteString("3 " , Font_7x9, White);
    	ssd1306_WriteNum(Mul_Temp[2], 3, "", !(edit!=0 && edit_string == 2));
    	ssd1306_SetCursorPos(0, 6, Font_7x9);
    	ssd1306_WriteString(string9_2[lang] , Font_7x9, White);
    	ssd1306_WriteString("4 " , Font_7x9, White);
    	ssd1306_WriteNum(Mul_Temp[3], 3, "", !(edit!=0 && edit_string == 3));

    break;


    case 10: //датчики

    	// датчик наружной температуры вкл/выкл
    	// если не подключен, значит система работает без погодозависимого регулирования

    	// датчик подачи вкл/выкл

    	// датчик ГВС/обратки/выкл

    	// датчик источника тепла вкл/выкл
    	ssd1306_SetCursorPos(5, 0, Font_7x9);
    	ssd1306_WriteString(string10_0[lang] , Font_7x9, White);
    	ssd1306_SetCursorPos(0, 2, Font_7x9);
    	ssd1306_WriteString(string10_1[lang] , Font_7x9, White);
        if (Temperature_visu[0]!=0)
        {
        	ssd1306_WriteString(string_on[lang], Font_7x9, !(edit!=0 && edit_string == 0));
        }
        else
        	ssd1306_WriteString(string_off[lang], Font_7x9, !(edit!=0 && edit_string == 0));
    	ssd1306_SetCursorPos(0, 3, Font_7x9);
    	ssd1306_WriteString(string10_2[lang] , Font_7x9, White);
        if (Temperature_visu[1]!=0)
        {
        	ssd1306_WriteString(string_on[lang], Font_7x9, !(edit!=0 && edit_string == 1));
        }
        else
        	ssd1306_WriteString(string_off[lang], Font_7x9, !(edit!=0 && edit_string == 1));
    	ssd1306_SetCursorPos(0, 4, Font_7x9);
    	ssd1306_WriteString(string10_3[lang] , Font_7x9, White);
        if (Temperature_visu[2]!=0)
        {
        	ssd1306_WriteString(string_on[lang], Font_7x9, !(edit!=0 && edit_string == 2));
        }
        else
        	ssd1306_WriteString(string_off[lang], Font_7x9, !(edit!=0 && edit_string == 2));
    	ssd1306_SetCursorPos(0, 5, Font_7x9);
    	ssd1306_WriteString(string10_4[lang] , Font_7x9, White);
        if (Temperature_visu[3]!=0)
        {
        	ssd1306_WriteString(string_on[lang], Font_7x9, !(edit!=0 && edit_string == 3));
        }
        else
        	ssd1306_WriteString(string_off[lang], Font_7x9, !(edit!=0 && edit_string == 3));

    	if (edit!=0 && key.key_left_rise) edit_string++;
		if (edit!=0 && key.key_right_rise) edit_string--;
		if (edit_string==255) edit_string++;
		if (edit_string==4) edit_string--;

    	if (edit!=0 && edit_string==0 && key.key_up_rise) Temperature_visu[0]=1;
    	if (edit!=0 && edit_string==0 && key.key_down_rise) Temperature_visu[0]=0;
    	if (edit!=0 && edit_string==1 && key.key_up_rise) Temperature_visu[1]=1;
    	if (edit!=0 && edit_string==1 && key.key_down_rise) Temperature_visu[1]=0;
    	if (edit!=0 && edit_string==2 && key.key_up_rise) Temperature_visu[2]=1;
    	if (edit!=0 && edit_string==2 && key.key_down_rise) Temperature_visu[2]=0;
    	if (edit!=0 && edit_string==3 && key.key_up_rise) Temperature_visu[3]=1;
    	if (edit!=0 && edit_string==3 && key.key_down_rise) Temperature_visu[3]=0;

    break;




    case 100:
    	  //--------------------------экран выключения прибора---------------

		ssd1306_SetCursorPos(6, 2, Font_7x9);
		ssd1306_WriteString(string100_0[lang] , Font_7x9, White);
		ssd1306_SetCursorPos(5, 3, Font_7x9);
		ssd1306_WriteString(string100_1[lang] , Font_7x9, White);
		ssd1306_SetCursorPos(0, 6, Font_7x9);
		if (gTime.Hours<10) ssd1306_WriteChar('0', Font_7x9, White);
		ssd1306_WriteNum(gTime.Hours, 0, ":", White);
		if (gTime.Minutes<10) ssd1306_WriteChar('0', Font_7x9, White);
		ssd1306_WriteNum(gTime.Minutes, 0, ":", White);
		if (gTime.Seconds<10) ssd1306_WriteChar('0', Font_7x9, White);
		ssd1306_WriteNum(gTime.Seconds, 0, "", White);
	break;

    default:
    	ssd1306_SetCursorPos(0, 0, Font_7x9);
    	ssd1306_WriteString(string10_0[lang] , Font_7x9, White);
    break;
  }
  ssd1306_UpdateScreen();
}




/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
