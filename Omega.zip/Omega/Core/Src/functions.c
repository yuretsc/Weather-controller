/*
 * Functions.c
 *
 *  Created on: Apr 8, 2020
 *      Author: Admin
 */
#include "functions.h"

#define ClearBit(A,k)   (A &= ~(1UL << k))
#define SetBit(A,k)    (A |= 1UL << k)
#define TestBit(A,k) ((A >> k) & 1UL)
#define ToggleBit(A,k)  ( A ^= 1UL << k)
#define Flash_size 50


extern int16_t Temperature[4];
extern discr_reg_DataType Boiler;
extern discr_reg_DataType WWS_pump;
extern int16_t Summ_Temp[4]; // измеренные температуры
extern int16_t Mul_Temp[4]; // измеренные температуры
extern 	int16_t Contrast;
extern uint8_t Power;
extern Flash_DataType Flash_memory;
extern int16_t Set_T_room;
extern int16_t Set_N_graph_shift;
extern int16_t S_graph_slope;
extern int16_t Set_T_max;
extern int16_t Set_Night_shift;
extern int16_t lang;
extern P_reg_DataType P_regDataFlow;
extern uint16_t Set_temp_WWS;// задание температуры ГВС
extern uint16_t Set_hyst_WWS;// задание гистерезиса ГВС
extern uint16_t Setpoint;
extern uint8_t Night_shift_time[7][6];
extern uint8_t Weather_curve_en;
extern uint8_t Priority_WWS;
extern uint8_t Antifrost;
extern uint8_t WWS_en;
extern uint16_t Boiler_WWS;
extern uint8_t Temperature_visu[4];
//extern uint16_t Boiler_hyst;


void discr_reg (discr_reg_DataType *reg)
{
	if (reg->en!=0)
	{

		if ((reg->in > (reg->set + reg->hyst)*10)&&(HAL_GetTick() > reg->time_privat + reg->min_time))
			{
			reg->out = 0;
			}

		if (reg->in < (reg->set - reg->hyst)*10)
			{
			reg->out = 1;
			reg->time_privat = HAL_GetTick();
			}
	}
	else reg->out = 0;
}

uint8_t func_error (error_DataType* code_error)
{

	code_error->etime_privat = 1000;
	code_error->dtime_privat = 60000;
	// угроза замерзания
/*
	if ((Temperature[0] < 3) && !TestBit(code_error->R_trig_privat,0))
		{
		SetBit(code_error->R_trig_privat, 0);
		code_error->time_privat[0] = HAL_GetTick();
		}
	if ((Temperature[0] < 3) && (code_error->etime_privat > HAL_GetTick() - code_error->time_privat[0]))
		{
		code_error->code = 0xB1;
		}
	if (Temperature[0] >= 3)
	{
		ClearBit(code_error->R_trig_privat,0);
	}
*/
	code_error->code = 0x00;
	if ((Temperature[1] < 3) && !TestBit(code_error->R_trig_privat,1))
		{
		SetBit(code_error->R_trig_privat, 1);
		code_error->time_privat[1] = HAL_GetTick();
		}
	if ((Temperature[1] < 3) && (code_error->etime_privat > HAL_GetTick() - code_error->time_privat[1]))
		{
		code_error->code = 0xB2;
		}
	if (Temperature[1] >= 3)
	{
		ClearBit(code_error->R_trig_privat,1);
	}

	if ((Temperature[2] < 3) && !TestBit(code_error->R_trig_privat,2))
		{
		SetBit(code_error->R_trig_privat, 2);
		code_error->time_privat[2] = HAL_GetTick();
		}
	if ((Temperature[2] < 3) && (code_error->etime_privat > HAL_GetTick() - code_error->time_privat[2]))
		{
		code_error->code = 0xB3;
		}
	if (Temperature[2] >= 3)
	{
		ClearBit(code_error->R_trig_privat,2);
	}

	if ((Temperature[3] < 3) && !TestBit(code_error->R_trig_privat,3))
		{
		SetBit(code_error->R_trig_privat, 3);
		code_error->time_privat[3] = HAL_GetTick();
		}
	if ((Temperature[3] < 3) && (code_error->etime_privat > HAL_GetTick() - code_error->time_privat[3]))
		{
		code_error->code = 0xB4;
		}
	if (Temperature[3] >= 3)
	{
		ClearBit(code_error->R_trig_privat,3);
	}


	// перегрев

	if ((Temperature[0] > code_error->T1_H) && !TestBit(code_error->R_trig_privat,8) && Temperature_visu[0])
		{
		SetBit(code_error->R_trig_privat, 8);
		code_error->time_privat[8] = HAL_GetTick();
		}
	if ((Temperature[0] > code_error->T1_H) && (code_error->etime_privat > HAL_GetTick() - code_error->time_privat[8]) && Temperature_visu[0])
		{
		code_error->code = 0xC1;
		}
	if (Temperature[0] <= code_error->T1_H || Temperature_visu[0] == 0)
	{
		ClearBit(code_error->R_trig_privat,8);
	}

	if ((Temperature[1] > code_error->T2_H) && !TestBit(code_error->R_trig_privat,9) && Temperature_visu[1])
		{
		SetBit(code_error->R_trig_privat, 9);
		code_error->time_privat[9] = HAL_GetTick();
		}
	if ((Temperature[1] > code_error->T2_H) && (code_error->etime_privat > HAL_GetTick() - code_error->time_privat[9]) && Temperature_visu[1])
		{
		code_error->code = 0xC2;
		}
	if (Temperature[1] <= code_error->T2_H || Temperature_visu[1])
	{
		ClearBit(code_error->R_trig_privat,9);
	}

	if ((Temperature[2] > code_error->T3_H) && !TestBit(code_error->R_trig_privat,10) && Temperature_visu[2])
		{
		SetBit(code_error->R_trig_privat, 10);
		code_error->time_privat[10] = HAL_GetTick();
		}
	if ((Temperature[2] > code_error->T3_H) && (code_error->etime_privat > HAL_GetTick() - code_error->time_privat[10]) && Temperature_visu[2])
		{
		code_error->code = 0xC3;
		}
	if (Temperature[2] <= code_error->T3_H)
	{
		ClearBit(code_error->R_trig_privat,10 ||  Temperature_visu[2]);
	}

	if ((Temperature[3] > code_error->T4_H) && !TestBit(code_error->R_trig_privat,11) && Temperature_visu[3])
		{
		SetBit(code_error->R_trig_privat, 11);
		code_error->time_privat[11] = HAL_GetTick();
		}
	if ((Temperature[3] > code_error->T4_H) && (code_error->etime_privat > HAL_GetTick() - code_error->time_privat[12])  && Temperature_visu[3])
		{
		code_error->code = 0xC4;
		}
	if (Temperature[3] <= code_error->T4_H || Temperature_visu[3])
	{
		ClearBit(code_error->R_trig_privat,11);
	}

//в обратке температура выше чем в подаче
	if (WWS_en==0)
	{
		if ((Temperature[3] > Temperature[2]) && !TestBit(code_error->R_trig_privat,12))
			{
			SetBit(code_error->R_trig_privat, 12);
			code_error->time_privat[13] = HAL_GetTick();
			}
		if ((Temperature[3] > Temperature[2]) && (code_error->etime_privat > HAL_GetTick() - code_error->time_privat[13]))
			{
			code_error->code = 0xE1;
			}
		if (Temperature[3] <= Temperature[2])
		{
			ClearBit(code_error->R_trig_privat,12);
		}
	}
	else
	{
		ClearBit(code_error->R_trig_privat,12);
	}
	//недогрев котла в течении времени
	if (Boiler.en)
	{
		if ((Temperature[4] < Boiler.set) && !TestBit(code_error->R_trig_privat,13))
			{
			SetBit(code_error->R_trig_privat, 13);
			code_error->time_privat[14] = HAL_GetTick();
			}
		if ((Temperature[4] < Boiler.set) && (code_error->dtime_privat > HAL_GetTick() - code_error->time_privat[14]))
			{
			code_error->code = 0xD1;
			}
		if (Temperature[4] >= Boiler.set)
		{
			ClearBit(code_error->R_trig_privat,13);
		}
	}
	else ClearBit(code_error->R_trig_privat,13);
	//недогрев ГВС в течении времени
	if (WWS_pump.en!=0)
	{
		if ((Temperature[1] < WWS_pump.set) && !TestBit(code_error->R_trig_privat,14))
			{
			SetBit(code_error->R_trig_privat, 14);
			code_error->time_privat[14] = HAL_GetTick();
			}
		if ((Temperature[1] < WWS_pump.set) && (code_error->dtime_privat > HAL_GetTick() - code_error->time_privat[15]))
			{
			code_error->code = 0xD2;
			}
		if (Temperature[1] >= WWS_pump.set)
		{
			ClearBit(code_error->R_trig_privat,14);
		}
	}
	else ClearBit(code_error->R_trig_privat,14);
	// неисправность датчика температуры
		if ((Temperature[0] == -125) && !TestBit(code_error->R_trig_privat,4) && Temperature_visu[0])
			{
			SetBit(code_error->R_trig_privat, 4);
			code_error->time_privat[4] = HAL_GetTick();
			}
		if ((Temperature[0] == -125) && (code_error->etime_privat > HAL_GetTick() - code_error->time_privat[4]) && Temperature_visu[0])
			{
			code_error->code = 0xA1;
			}
		if (Temperature[0] != -125 || Temperature_visu[0] == 0)
		{
			ClearBit(code_error->R_trig_privat,4);
		}

		if ((Temperature[1] == -125) && !TestBit(code_error->R_trig_privat,5))
			{
			SetBit(code_error->R_trig_privat, 5);
			code_error->time_privat[5] = HAL_GetTick();
			}
		if ((Temperature[1] == -125) && (code_error->etime_privat > HAL_GetTick() - code_error->time_privat[5]))
			{
			code_error->code = 0xA2;
			}
		if (Temperature[1] != -125)
		{
			ClearBit(code_error->R_trig_privat,5);
		}

		if ((Temperature[2] == -125) && !TestBit(code_error->R_trig_privat,6))
			{
			SetBit(code_error->R_trig_privat, 6);
			code_error->time_privat[6] = HAL_GetTick();
			}
		if ((Temperature[2] == -125) && (code_error->etime_privat > HAL_GetTick() - code_error->time_privat[6]))
			{
			code_error->code = 0xA3;
			}
		if (Temperature[2] != -125)
		{
			ClearBit(code_error->R_trig_privat,6);
		}

		if ((Temperature[3] == -125) && !TestBit(code_error->R_trig_privat,7))
			{
			SetBit(code_error->R_trig_privat, 7);
			code_error->time_privat[7] = HAL_GetTick();
			}
		if ((Temperature[3] == -125) && (code_error->etime_privat > HAL_GetTick() - code_error->time_privat[7]))
			{
			code_error->code = 0xA4;
			}
		if (Temperature[3] != -125)
		{
			ClearBit(code_error->R_trig_privat,7);
		}

	if 	(code_error->R_trig_privat==0)	code_error->code = 0x00;
 return code_error->code;
}

void func_key (key_DataType* key)
{
	//-----------------------up----------------------------
	if ((key->key_up!=0) && !TestBit(key->R_trig_privat,0))//фронт нажатия, начало отсчета для подавления дребезга
	{
		SetBit(key->R_trig_privat, 0);
		key->time_privat[0] = HAL_GetTick();
	}
	if ((key->key_up!=0) && (20 < HAL_GetTick() - key->time_privat[0]))
	{
		key->key_up = HAL_GetTick() - key->time_privat[0];
	}
	if (key->key_up==0)
	{
		ClearBit(key->R_trig_privat, 0);
		key->time_privat[0]=0;
	}
	if (key->time_privat[0] == 0 && key->time_privat[4] != 0) key->key_up_fall = 1, key->key_up_rise = 0;
	if (key->time_privat[0] == 0 && key->time_privat[4] == 0) key->key_up_fall = 0, key->key_up_rise = 0;
	if (key->time_privat[0] != 0 && key->time_privat[4] == 0) key->key_up_rise = 1, key->key_up_fall = 0;
	if (key->time_privat[0] != 0 && key->time_privat[4] != 0) key->key_up_rise = 0, key->key_up_fall = 0;
	key->time_privat[4] = key->time_privat[0]; //save last value

	//-----------------------down----------------------------
	if ((key->key_down!=0) && !TestBit(key->R_trig_privat,1))
	{
		SetBit(key->R_trig_privat, 1);
		key->time_privat[1] = HAL_GetTick();
	}
	if ((key->key_down!=0) && (20 < HAL_GetTick() - key->time_privat[1]))
	{
		key->key_down = HAL_GetTick() - key->time_privat[1];
	}
	if (key->key_down==0)
	{
		ClearBit(key->R_trig_privat, 1);
		key->time_privat[1]=0;
	}
	if (key->time_privat[1] == 0 && key->time_privat[5] != 0) key->key_down_fall = 1, key->key_down_rise = 0;
	if (key->time_privat[1] == 0 && key->time_privat[5] == 0) key->key_down_fall = 0, key->key_down_rise = 0;
	if (key->time_privat[1] != 0 && key->time_privat[5] == 0) key->key_down_rise = 1, key->key_down_fall = 0;
	if (key->time_privat[1] != 0 && key->time_privat[5] != 0) key->key_down_rise = 0, key->key_down_fall = 0;
	key->time_privat[5] = key->time_privat[1]; //save last value
	//-----------------------left----------------------------
	if ((key->key_left!=0) && !TestBit(key->R_trig_privat,2))
	{
		SetBit(key->R_trig_privat, 2);
		key->time_privat[2] = HAL_GetTick();
	}
	if ((key->key_left!=0) && (20 < HAL_GetTick() - key->time_privat[2]))
	{
		key->key_left = HAL_GetTick() - key->time_privat[2];
	}
	if (key->key_left==0)
	{
		ClearBit(key->R_trig_privat, 2);
		key->time_privat[2]=0;
	}
	if (key->time_privat[2] == 0 && key->time_privat[6] != 0) key->key_left_fall = 1, key->key_left_rise = 0;
	if (key->time_privat[2] == 0 && key->time_privat[6] == 0) key->key_left_fall = 0, key->key_left_rise = 0;
	if (key->time_privat[2] != 0 && key->time_privat[6] == 0) key->key_left_rise = 1, key->key_left_fall = 0;
	if (key->time_privat[2] != 0 && key->time_privat[6] != 0) key->key_left_rise = 0, key->key_left_fall = 0;
	key->time_privat[6] = key->time_privat[2]; //save last value
	//-----------------------right----------------------------
	if ((key->key_right!=0) && !TestBit(key->R_trig_privat,3))
	{
		SetBit(key->R_trig_privat, 3);
		key->time_privat[3] = HAL_GetTick();
	}
	if ((key->key_right!=0) && (20 < HAL_GetTick() - key->time_privat[3]))
	{
		key->key_right = HAL_GetTick() - key->time_privat[3];
	}
	if (key->key_right==0)
	{
		ClearBit(key->R_trig_privat, 3);
		key->time_privat[3]=0;
	}
	if (key->time_privat[3] == 0 && key->time_privat[7] != 0) key->key_right_fall = 1, key->key_right_rise = 0;
	if (key->time_privat[3] == 0 && key->time_privat[7] == 0) key->key_right_fall = 0, key->key_right_rise = 0;
	if (key->time_privat[3] != 0 && key->time_privat[7] == 0) key->key_right_rise = 1, key->key_right_fall = 0;
	if (key->time_privat[3] != 0 && key->time_privat[7] != 0) key->key_right_rise = 0, key->key_right_fall = 0;
	key->time_privat[7] = key->time_privat[3]; //save last value
}

void PDD_PWM (P_reg_DataType *pid)
{
	float error;
	float derror;
	float dderror;
	static uint32_t lastperiod;
	static float imp_time_save;

	if (pid->en!=0)
	{
		if (HAL_GetTick() > lastperiod + (uint32_t)pid->period*1000)//вызов регулятора по времени
		{
			// The  error term
			error = (float)((pid->set) - (pid->input));
			// The  diff error term
			derror = error -  (float)((pid->set) - pid->lastInput);
			// The  diff^2 error term
			dderror = error - 2* derror + (float)((pid->set) - (pid->lastlastInput));
	// вычисление  длинны и знака импульса управления
			// длинна имп = время открытия клапана/100*K*derror+K*error/Ti+K*dderror/время вызова регулятора + сохраненное с прошлого раза
			//https://core.ac.uk/download/pdf/53064575.pdf
			pid->imp_time = (float)pid->valve_time/100.0*((float)pid->K*derror + (float)pid->K*(float)pid->period*error/
					(float)pid->Ti + (float)pid->K*(float)pid->Td*dderror/(float)pid->period) + imp_time_save;  //unit ms

			// ограничение импульса до минимального для механизма (сохранять накопленное значение и суммировать)
			if (fabs(pid->imp_time) < (float)pid->min_valve_time)
				{
				imp_time_save = imp_time_save + pid->imp_time;
				pid->imp_time = 0.0;
				}
			// вычисление  направления вращения механизма
			else if (pid->imp_time!= 0.0)
			{
				if (pid->imp_time>0.0) pid->up = 1, pid->down = 0, imp_time_save = 0;
				if (pid->imp_time<0.0) pid->up = 0, pid->down = 1, pid->imp_time=pid->imp_time*-1, imp_time_save = 0;
			}

			// ограничение импусльса до максимального, равному периоду вызова регулятора
			if ((uint32_t)pid->imp_time > (uint32_t)pid->period*1000)  pid->imp_time = (float)pid->period*1000;

			pid->lastlastInput = pid->lastInput;
			pid->lastInput = (pid->input);
			lastperiod = HAL_GetTick();
		}

		if (HAL_GetTick() > lastperiod + (uint32_t)pid->imp_time) pid->up = 0, pid->down = 0;
	}
	else pid->up = 0, pid->down = 0, lastperiod = 0, pid->lastInput = 0, pid->lastlastInput = 0;
}

void FLASH_Write (uint32_t *data, uint32_t adres, uint16_t length)
{
	FLASH_EraseInitTypeDef EraseInitStruct;
	uint32_t PAGEError = 0;
	HAL_FLASH_Unlock();               // Разблокируем флеш память

	EraseInitStruct.Banks = FLASH_BANK_1;
	EraseInitStruct.TypeErase = FLASH_TYPEERASE_PAGES;
	EraseInitStruct.NbPages =1;
	EraseInitStruct.PageAddress = adres;
	HAL_FLASHEx_Erase(&EraseInitStruct, &PAGEError);    // Очищаем страницу 63 флеш памяти
	__HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_OPTVERR);
	for (uint16_t i=0; i<=length; i++)
	   {
	    HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, adres+4*i, data[i]);   // Записываем значение переменной isTimeWorkL на 63 странице флеш памяти
	   }
	HAL_FLASH_Lock();                // Блокируем флеш память
}

int16_t limit (int16_t data, int16_t min, int16_t max)
{
	if (data < min) return min;
	if (data > max) return max;
	return data;
}

// расчет глобального таймера и запись в него
uint32_t RTC_GetRTC_Counter(RTC_DateTypeDef* RTC_DateStruct, RTC_TimeTypeDef* RTC_TimeStruct )
{
	uint8_t a;
	uint16_t y;
	uint8_t m;
	uint32_t JDN;
#define JULIAN_DATE_BASE	2440588

	a=(14 - RTC_DateStruct->Month) / 12;
	y=2000+RTC_DateStruct->Year+4800-a;
	m=RTC_DateStruct->Month+(12*a)-3;

	JDN=RTC_DateStruct->Date;
	JDN+=(153*m+2)/5;
	JDN+=365*y;
	JDN+=y/4;
	JDN+=-y/100;
	JDN+=y/400;
	JDN = JDN -32045;
	JDN = JDN - JULIAN_DATE_BASE;
	JDN*=86400;
	JDN+=(RTC_TimeStruct->Hours*3600);
	JDN+=(RTC_TimeStruct->Minutes*60);
	JDN+=(RTC_TimeStruct->Seconds);
	return JDN;
}

// Get current date
void RTC_GetDateTime(uint32_t RTC_Counter, RTC_DateTypeDef* RTC_DateStruct/*, RTC_TimeTypeDef* RTC_TimeStruct*/) {
	unsigned long time;
	unsigned long t1, a, b, c, d, e, m;
	int year = 0;
	int mon = 0;
//	int wday = 0;// не используется
	int mday = 0;
//	int hour = 0;
//	int min = 0;
//	int sec = 0;
	uint64_t jd = 0;;
	uint64_t jdn = 0;

	jd = ((RTC_Counter+43200)/(86400>>1)) + (2440587<<1) + 1;
	jdn = jd>>1;

	time = RTC_Counter;
	t1 = time/60;
//	sec = time - t1*60;

	time = t1;
	t1 = time/60;
//	min = time - t1*60;

	time = t1;
	t1 = time/24;
//	hour = time - t1*24;

//	wday = jdn%7;

	a = jdn + 32044;
	b = (4*a+3)/146097;
	c = a - (146097*b)/4;
	d = (4*c+3)/1461;
	e = c - (1461*d)/4;
	m = (5*e+2)/153;
	mday = e - (153*m+2)/5 + 1;
	mon = m + 3 - 12*(m/10);
	year = 100*b + d - 4800 + (m/10)-2000;//формат ХХ

	RTC_DateStruct->Year = year;
	RTC_DateStruct->Month = mon;
	RTC_DateStruct->Date = mday;
//	RTC_TimeStruct->Hours = hour;
//	RTC_TimeStruct->Minutes = min;
//	RTC_TimeStruct->Seconds = sec;
}

void Flash_memory_write (void)
{
	Flash_memory.P_regDataFlow_K = P_regDataFlow.K;
	Flash_memory.P_regDataFlow_Ti = P_regDataFlow.Ti;
	Flash_memory.P_regDataFlow_Td = P_regDataFlow.Td;
	Flash_memory.P_regDataFlow_valve_time = P_regDataFlow.valve_time;
	Flash_memory.P_regDataFlow_min_valve_time = P_regDataFlow.min_valve_time;
	Flash_memory.P_regDataFlow_lag_valve_time = P_regDataFlow.lag_valve_time;
	Flash_memory.P_regDataFlow_valve_time_pause = P_regDataFlow.valve_time_pause;
	Flash_memory.P_regDataFlow_Flow_period = P_regDataFlow.period;
	Flash_memory.Weather_curve_Set_T_room = Set_T_room;
	Flash_memory.Weather_curve_Set_N_graph_shift = Set_N_graph_shift;
	Flash_memory.Weather_curve_S_graph_slope = S_graph_slope;
	Flash_memory.Weather_curve_Set_T_max = Set_T_max;
	Flash_memory.Weather_curve_Set_Night_shift = Set_Night_shift;
	Flash_memory.lang_flash = lang;
	Flash_memory.Set_temp_WWS = Set_temp_WWS;
	Flash_memory.Set_hyst_WWS = Set_hyst_WWS;
	Flash_memory.Mul_Temp[0] = Mul_Temp[0];
	Flash_memory.Mul_Temp[1] = Mul_Temp[1];
	Flash_memory.Mul_Temp[2] = Mul_Temp[2];
	Flash_memory.Mul_Temp[3] = Mul_Temp[3];
	Flash_memory.Summ_Temp[0] = Summ_Temp[0];
	Flash_memory.Summ_Temp[1] = Summ_Temp[1];
	Flash_memory.Summ_Temp[2] = Summ_Temp[2];
	Flash_memory.Summ_Temp[3] = Summ_Temp[3];
	Flash_memory.Contrast = Contrast;
	Flash_memory.Power = Power;
	Flash_memory.Weather_curve_en = Weather_curve_en;
	Flash_memory.Setpoint = Setpoint;
	Flash_memory.Priority_WWS = Priority_WWS;
	Flash_memory.Antifrost = Antifrost;
	Flash_memory.WWS_en = WWS_en;
	Flash_memory.Boiler_WWS = Boiler_WWS;
	Flash_memory.Boiler_hyst = Boiler.hyst;
	Flash_memory.Temperature_visu[0] = Temperature_visu[0];
	Flash_memory.Temperature_visu[1] = Temperature_visu[1];
	Flash_memory.Temperature_visu[2] = Temperature_visu[2];
	Flash_memory.Temperature_visu[3] = Temperature_visu[3];

	for (int i = 0; i < 7; ++i)
	{
	  for (int j = 0; j < 6; ++j)
		  Flash_memory.Night_shift_time_flash[i][j] = Night_shift_time[i][j];
	}

  FLASH_Write (&Flash_memory, 0x0801FC00, Flash_size); // запись в последнюю страницу памяти
}


